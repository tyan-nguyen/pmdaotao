<?php

use yii\bootstrap5\Html;

/* @var $this yii\web\View */
/* @var $model app\models\HvHocVien */
?>
<div class="hv-hoc-vien-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
