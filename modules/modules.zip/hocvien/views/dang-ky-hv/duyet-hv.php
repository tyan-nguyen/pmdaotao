<?php

use yii\bootstrap5\Html;

/* @var $this yii\web\View */
/* @var $model app\models\HvHocVien */
?>
<div class="duyet-hv">

    <?= $this->render('_formDuyetHV', [
        'model' => $model,
    ]) ?>

</div>