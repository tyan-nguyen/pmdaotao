<?php
echo 'Báo cáo tổng';