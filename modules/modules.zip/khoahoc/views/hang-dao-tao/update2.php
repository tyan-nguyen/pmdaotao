<?php

use yii\bootstrap5\Html;

?>
<div class="hoc-phi-update">

    <?= $this->render('_formHP', [
        'model' => $model,
    ]) ?>

</div>