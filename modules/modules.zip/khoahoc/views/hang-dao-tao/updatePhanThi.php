<?php

use yii\bootstrap5\Html;

?>
<div class="phan-thi-update">

    <?= $this->render('_formPhanThi', [
        'model' => $model,
    ]) ?>

</div>