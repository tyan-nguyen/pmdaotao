<?php

use yii\bootstrap5\Html;


/* @var $this yii\web\View */
/* @var $model app\modules\khoahoc\models\KhoaHoc */

?>
<div class="khoa-hoc-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>