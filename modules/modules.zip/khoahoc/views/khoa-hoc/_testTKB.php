
<?php
   echo "TRang render";
?>
<p> Đây là trang render </p>