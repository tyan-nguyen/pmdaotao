<?php

use yii\bootstrap5\Html;


/* @var $this yii\web\View */
/* @var $model app\models\HvHocVien */

?>
<div class="create_lich_thi">
    <?= $this->render('_formCreateLT', [
        'model' => $model,
        'idKH'=>$idKH,
    ]) ?>
</div>