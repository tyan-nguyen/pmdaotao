<?php

use yii\bootstrap5\Html;

?>
<div class="nhom-update">

    <?= $this->render('_formUdNhom', [
        'model' => $model,
        
    ]) ?>

</div>