<?php

use yii\bootstrap5\Html;

?>
<div class="chi-tiet-nhom-update">

    <?= $this->render('_formUdCTNhom', [
        'model' => $model,
        
    ]) ?>

</div>