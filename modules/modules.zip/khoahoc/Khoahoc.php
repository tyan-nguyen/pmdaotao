<?php

namespace app\modules\khoahoc;

/**
 * khoahoc module definition class
 */
class Khoahoc extends \yii\base\Module
{
    /**
     * {@inheritdoc}
     */
    public $controllerNamespace = 'app\modules\khoahoc\controllers';

    /**
     * {@inheritdoc}
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
