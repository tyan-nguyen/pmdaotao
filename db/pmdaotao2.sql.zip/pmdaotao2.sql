-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 31, 2025 at 01:10 PM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmdaotao2`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Admin', 1, 1730084952),
('nQuanLyHoSoDangKy', 5, 1743340973),
('nQuanLyHoSoHocVien', 5, 1743318205),
('user_4_', 4, 1743211239),
('user_5_', 5, 1743290927),
('user_6_', 6, 1743287817),
('user_7_', 7, 1743287842);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `rule_name` varchar(64) DEFAULT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/giaovien/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/day/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/day/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/day/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/day/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/day/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/day/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/get-to-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/insert-phong-ban', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/insert-to', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/load-schedule-week', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/giaovien/giao-vien/view2', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/gridview/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/gridview/export/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/gridview/export/download', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/gridview/grid-edited-row/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/gridview/grid-edited-row/back', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/create2', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/duyet-hv', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/get-phieu-in-ajax', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/update-print-count', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-hv/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-online/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/dang-ky-online/dang-ky', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/bien-lai', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/create-hp', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/create-ket-qua-thi', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/create2', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/delete-from-khoa-hoc', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/get-diem-dat-toi-thieu', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/get-giao-vien-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/get-lich-thi-ajax', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/get-nhom-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/get-phieu-in-ajax', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/get-results', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/get-thu-tu-thi', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/get-to-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/insert-ket-qua-thi', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/load-schedule-week', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/mess', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/mess2', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/reload-data', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/update-lich-hoc', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hocvien/hoc-vien/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hv-khoa-hoc/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hv-khoa-hoc/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hv-khoa-hoc/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hv-khoa-hoc/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hv-khoa-hoc/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hv-khoa-hoc/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/hv-khoa-hoc/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/hang-dao-tao/*', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/bulkdelete', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/create', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/delete', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/index', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/list-hoc-phi', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/list-phan-thi', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/them-phan-thi', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/tuition', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/update', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/update-list-hoc-phi', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/update-list-phan-thi', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/update2', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/hang-dao-tao/view', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/khoa-hoc/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/add-group', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/add-nhom', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/add-students-to-group', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/create', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/khoa-hoc/create-lich-hoc-from-khoa-hoc', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/create-lich-thi', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/danh-sach-nhom', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/delete', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/khoa-hoc/delete-nhom', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/details-ket-qua-thi', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/get-giao-vien-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/get-nhom-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/get-phieu-in-ajax', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/group-details', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/index', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/khoa-hoc/insert-hoc-vien', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/insert-many-hoc-vien', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/load-schedule', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/load-schedule-week', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/update', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/khoahoc/khoa-hoc/update-lich-hoc', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/update-nhom', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/update-nhom-hoc', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/khoahoc/khoa-hoc/view', 3, NULL, NULL, NULL, 1743292554, 1743292554, NULL),
('/kholuutru/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/download', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/reload', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/upload-multi', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/upload-multi-process', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/upload-single', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/file/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ho-so-kho/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ho-so-kho/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ho-so-kho/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ho-so-kho/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ho-so-kho/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ho-so-kho/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ho-so-kho/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/hop/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/hop/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/hop/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/hop/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/hop/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/hop/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/hop/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ke/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ke/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ke/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ke/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ke/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ke/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ke/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/kho/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/kho/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/kho/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/kho/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/kho/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/kho/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/kho/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/loai-file/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/loai-file/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/loai-file/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/loai-file/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/loai-file/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/loai-file/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/loai-file/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/get-file', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/get-hop-by-ngan', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/get-ke-by-kho', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/get-loai-file', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/get-ngan-by-ke', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/get-to-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/get-to-list-ke', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/get-to-list-ngan', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/luu-kho/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ngan/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ngan/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ngan/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ngan/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ngan/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ngan/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/kholuutru/ngan/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/ket-qua-thi/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/ket-qua-thi/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/ket-qua-thi/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/ket-qua-thi/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/ket-qua-thi/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/ket-qua-thi/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/ket-qua-thi/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-hoc/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-hoc/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-hoc/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-hoc/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-hoc/get-giao-vien-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-hoc/get-nhom-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-hoc/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-hoc/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-hoc/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-thi/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-thi/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-thi/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-thi/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-thi/get-nhom-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-thi/get-phan-hang', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-thi/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-thi/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/lich-thi/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phan-thi/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phan-thi/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phan-thi/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phan-thi/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phan-thi/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phan-thi/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phan-thi/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phong-hoc/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phong-hoc/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phong-hoc/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phong-hoc/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phong-hoc/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phong-hoc/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/lichhoc/phong-hoc/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/nhan-vien/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/nhan-vien/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/nhan-vien/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/nhan-vien/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/nhan-vien/get-to-list', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/nhan-vien/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/nhan-vien/insert-phong-ban', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/nhan-vien/insert-to', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/nhan-vien/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/nhan-vien/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/phong-ban/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/phong-ban/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/phong-ban/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/phong-ban/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/phong-ban/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/phong-ban/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/phong-ban/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/to/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/to/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/to/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/to/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/to/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/to/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/nhanvien/to/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/site/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/site/about', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/site/captcha', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/site/contact', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/site/error', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/site/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/site/login', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/site/logout', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-hinh-thue/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-hinh-thue/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-hinh-thue/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-hinh-thue/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-hinh-thue/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-hinh-thue/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-hinh-thue/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-xe/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-xe/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-xe/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-xe/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-xe/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-xe/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/loai-xe/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/approve', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/bien-lai', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/get-loai-hinh-thue', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/get-phieu-in-ajax', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/mess', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/mess-duyet-sc', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/mess-kdp', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/mess-sc', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/nop-phi-thue-xe', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/sent', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/thong-bao-chua-duyet', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/tinh-chi-phi', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/tinh-chi-phi-phat-sinh', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/tra-xe', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/xem-thong-tin-duyet-phieu', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/xem-thong-tin-phi-thue', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/phieu-thue-xe/xem-tra-xe', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/add-image', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/add-images', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/delete-image', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/delete-single-image', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/upload-images', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/thuexe/xe/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/auth-item-group/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/bulk-activate', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/bulk-deactivate', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/bulk-delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/grid-page-size', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/grid-sort', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/toggle-attribute', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth-item-group/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth/captcha', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/auth/confirm-email', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth/confirm-email-receive', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth/confirm-registration-email', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth/login', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth/logout', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth/password-recovery', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth/password-recovery-receive', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/auth/registration', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/bulk-activate', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/bulk-deactivate', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/bulk-delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/grid-page-size', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/grid-sort', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/refresh-routes', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/set-child-permissions', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/set-child-routes', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/toggle-attribute', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/permission/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/bulk-activate', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/bulk-deactivate', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/bulk-delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/grid-page-size', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/grid-sort', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/set-child-permissions', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/set-child-roles', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/toggle-attribute', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/role/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-permission/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user-visit-log/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/bulk-activate', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/bulk-deactivate', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/bulk-delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/grid-page-size', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/grid-sort', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/toggle-attribute', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user-visit-log/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user/grid-sort', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user/toggle-attribute', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/captcha', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/change-own-password', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/confirm-email', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/confirm-email-receive', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/confirm-registration-email', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/login', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/logout', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/password-recovery', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/password-recovery-receive', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/auth/registration', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/default/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/default/index', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/giao-dien/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/giao-dien/index', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-ajax/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-ajax/bulkdelete', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-ajax/change-password', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-ajax/create', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-ajax/delete', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-ajax/index', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-ajax/update', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-ajax/view', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-permission/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-permission/set', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user-permission/set-roles', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/*', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/activity', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/bulk-activate', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/bulk-deactivate', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/bulk-delete', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/change-password', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/create', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/delete', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/grid-page-size', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/grid-sort', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/index', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/toggle-attribute', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/update', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/user/user/view', 3, NULL, NULL, NULL, 1724233959, 1724233959, NULL),
('/vanban/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/dm-loai-vb/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/dm-loai-vb/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/dm-loai-vb/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/dm-loai-vb/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/dm-loai-vb/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/dm-loai-vb/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/dm-loai-vb/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/van-ban/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/van-ban/tra-cuu', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-den/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-den/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-den/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-den/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-den/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-den/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-den/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-di/*', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-di/bulkdelete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-di/create', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-di/delete', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-di/index', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-di/update', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('/vanban/vb-di/view', 3, NULL, NULL, NULL, 1743292553, 1743292553, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1724233959, 1724233959, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1724233959, 1724233959, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1724233958, 1724233958, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('nQuanLyHoSoDangKy', 1, 'Quản lý hồ sơ đăng ký', NULL, NULL, 1743305419, 1743305419, NULL),
('nQuanLyHoSoHocVien', 1, 'Quản lý hồ sơ học viên', NULL, NULL, 1743305419, 1743305419, NULL),
('qDongHocPhi', 2, 'Quyền đóng học phí', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoHocVien'),
('qSuaHocVien', 2, 'Quyền Sửa học viên', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoHocVien'),
('qSuaHocVienDangKy', 2, 'Quyền sửa học viên đăng ký', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoDangKy'),
('qThemDongHocPhiDangKy', 2, 'Quyền thêm đóng học phí', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoDangKy'),
('qThemHocVien', 2, 'Quyền Thêm mới học viên', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoHocVien'),
('qThemHocVienDangKy', 2, 'Quyền thêm học viên đăng ký', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoDangKy'),
('qXemDanhSachHocVien', 2, 'Quyền Xem danh sách học viên', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoHocVien'),
('qXemDanhSachHocVienDangKy', 2, 'Quyền xem danh sách học viên đăng ký', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoDangKy'),
('qXemHocVien', 2, 'Quyền Xem học viên', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoHocVien'),
('qXemHocVienDangKy', 2, 'Quyền xem học viên đăng ký', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoDangKy'),
('qXoaHocVien', 2, 'Quyền Xóa học viên', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoHocVien'),
('qXoaHocVienDangKy', 2, 'Quyền xóa học viên đăng ký', NULL, NULL, 1743305419, 1743305419, 'quanLyHoSoDangKy'),
('user_1_', 1, 'Quyền tùy chỉnh cho user khanhquy', NULL, NULL, 1724916420, 1724916420, NULL),
('user_2_', 1, 'Quyền tùy chỉnh cho user Doremon', NULL, NULL, 1724916443, 1724916443, NULL),
('user_4_', 1, 'Quyền tùy chỉnh cho user superadmin', NULL, NULL, 1743211239, 1743211239, NULL),
('user_5_', 1, 'Quyền tùy chỉnh cho user quetran', NULL, NULL, 1743290927, 1743290927, NULL),
('user_6_', 1, 'Quyền tùy chỉnh cho user thaitran', NULL, NULL, 1743287817, 1743287817, NULL),
('user_7_', 1, 'Quyền tùy chỉnh cho user admin', NULL, NULL, 1743287842, 1743287842, NULL),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1724233959, 1724233959, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1724233959, 1724233959, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('qXoaHocVienDangKy', '/hocvien/dang-ky-hv/bulkdelete'),
('qThemHocVienDangKy', '/hocvien/dang-ky-hv/create'),
('qThemDongHocPhiDangKy', '/hocvien/dang-ky-hv/create2'),
('qXoaHocVienDangKy', '/hocvien/dang-ky-hv/delete'),
('qXemDanhSachHocVienDangKy', '/hocvien/dang-ky-hv/index'),
('qSuaHocVienDangKy', '/hocvien/dang-ky-hv/update'),
('qXemHocVienDangKy', '/hocvien/dang-ky-hv/view'),
('qDongHocPhi', '/hocvien/hoc-vien/bien-lai'),
('qXoaHocVien', '/hocvien/hoc-vien/bulkdelete'),
('qThemHocVien', '/hocvien/hoc-vien/create'),
('qXoaHocVien', '/hocvien/hoc-vien/delete'),
('qXemDanhSachHocVien', '/hocvien/hoc-vien/index'),
('qDongHocPhi', '/hocvien/hoc-vien/mess'),
('qDongHocPhi', '/hocvien/hoc-vien/mess2'),
('qSuaHocVien', '/hocvien/hoc-vien/update'),
('qXemHocVien', '/hocvien/hoc-vien/view'),
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('user_1_', 'editUsers'),
('nQuanLyHoSoHocVien', 'qDongHocPhi'),
('nQuanLyHoSoHocVien', 'qSuaHocVien'),
('nQuanLyHoSoDangKy', 'qSuaHocVienDangKy'),
('nQuanLyHoSoDangKy', 'qThemDongHocPhiDangKy'),
('user_5_', 'qThemDongHocPhiDangKy'),
('nQuanLyHoSoHocVien', 'qThemHocVien'),
('nQuanLyHoSoDangKy', 'qThemHocVienDangKy'),
('user_5_', 'qThemHocVienDangKy'),
('nQuanLyHoSoHocVien', 'qXemDanhSachHocVien'),
('nQuanLyHoSoDangKy', 'qXemDanhSachHocVienDangKy'),
('user_5_', 'qXemDanhSachHocVienDangKy'),
('nQuanLyHoSoHocVien', 'qXemHocVien'),
('nQuanLyHoSoDangKy', 'qXemHocVienDangKy'),
('user_5_', 'qXemHocVienDangKy'),
('nQuanLyHoSoHocVien', 'qXoaHocVien'),
('nQuanLyHoSoDangKy', 'qXoaHocVienDangKy'),
('editUserEmail', 'viewUserEmail'),
('user_1_', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('quanLyHoSoDangKy', 'Quản lý hồ sơ đăng ký', 1743305419, 1743305419),
('quanLyHoSoHocVien', 'Quản lý hồ sơ học viên', 1743305419, 1743305419),
('userCommonPermissions', 'User common permission', 1724233959, 1724233959),
('userManagement', 'User management', 1724233959, 1724233959);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `hv_hang_dao_tao`
--

DROP TABLE IF EXISTS `hv_hang_dao_tao`;
CREATE TABLE IF NOT EXISTS `hv_hang_dao_tao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_hang` varchar(255) NOT NULL,
  `ghi_chu` text,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `check_phan_hang` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hv_hang_dao_tao`
--

INSERT INTO `hv_hang_dao_tao` (`id`, `ten_hang`, `ghi_chu`, `nguoi_tao`, `thoi_gian_tao`, `check_phan_hang`) VALUES
(1, 'Hạng B số tự động (ngày thường)', '', NULL, '2025-03-25 14:40:09', 'OTO'),
(2, 'Hạng B số tự động (ngày T7-CN)', '', NULL, '2025-03-25 14:41:16', 'OTO'),
(3, 'Hạng B số cơ khí (ngày thường)', NULL, NULL, '2025-03-25 14:41:32', 'OTO'),
(4, 'Hạng B số cơ khí (ngày T7-CN)', '', NULL, '2025-03-25 14:41:51', 'OTO'),
(5, 'Hạng C1 (ngày thường)', '', NULL, '2025-03-25 14:42:07', 'OTO'),
(6, 'Hạng C1 (ngày T7-CN)', '', NULL, '2025-03-25 14:42:21', 'OTO');

-- --------------------------------------------------------

--
-- Table structure for table `hv_hoc_phi`
--

DROP TABLE IF EXISTS `hv_hoc_phi`;
CREATE TABLE IF NOT EXISTS `hv_hoc_phi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_hang` int(11) NOT NULL,
  `hoc_phi` double NOT NULL,
  `ngay_ap_dung` date NOT NULL,
  `ngay_ket_thuc` date NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_hang_hp_hang` (`id_hang`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hv_hoc_phi`
--

INSERT INTO `hv_hoc_phi` (`id`, `id_hang`, `hoc_phi`, `ngay_ap_dung`, `ngay_ket_thuc`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(25, 1, 19500000, '2025-04-01', '2025-12-31', 4, '2025-03-29 09:12:49'),
(26, 2, 21000000, '2025-04-01', '2025-12-31', 4, '2025-03-29 09:14:00'),
(27, 3, 19500000, '2025-03-26', '2025-12-31', 4, '2025-03-29 09:14:42'),
(28, 4, 21000000, '2025-04-01', '2025-12-31', 4, '2025-03-29 09:15:19'),
(29, 5, 21000000, '2025-03-29', '2025-12-31', 4, '2025-03-29 09:17:33'),
(30, 6, 22000000, '2025-03-29', '2025-12-31', 4, '2025-03-29 09:27:56');

-- --------------------------------------------------------

--
-- Table structure for table `hv_hoc_vien`
--

DROP TABLE IF EXISTS `hv_hoc_vien`;
CREATE TABLE IF NOT EXISTS `hv_hoc_vien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_khoa_hoc` int(11) DEFAULT NULL,
  `ho_ten` varchar(255) NOT NULL,
  `so_dien_thoai` varchar(255) NOT NULL,
  `so_cccd` varchar(255) DEFAULT NULL,
  `ngay_het_han_cccd` date DEFAULT NULL,
  `trang_thai` varchar(255) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `gioi_tinh` int(11) DEFAULT NULL,
  `dia_chi` varchar(255) DEFAULT NULL,
  `ngay_sinh` date DEFAULT NULL,
  `nguoi_lap_phieu` varchar(55) DEFAULT NULL,
  `ma_so_phieu` int(11) DEFAULT NULL,
  `so_lan_in_phieu` int(11) DEFAULT NULL,
  `id_hang` int(11) NOT NULL,
  `check_hoc_phi` varchar(25) DEFAULT NULL,
  `id_nhom` int(11) DEFAULT NULL,
  `loai_dang_ky` varchar(15) DEFAULT NULL,
  `noi_dang_ky` varchar(50) DEFAULT NULL,
  `nguoi_duyet` int(11) DEFAULT NULL,
  `trang_thai_duyet` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_khoa_hoc_khoa_hoc` (`id_khoa_hoc`),
  KEY `fk-id_hang_hang_dao_tao` (`id_hang`),
  KEY `fk_nhom` (`id_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hv_hoc_vien`
--

INSERT INTO `hv_hoc_vien` (`id`, `id_khoa_hoc`, `ho_ten`, `so_dien_thoai`, `so_cccd`, `ngay_het_han_cccd`, `trang_thai`, `nguoi_tao`, `thoi_gian_tao`, `gioi_tinh`, `dia_chi`, `ngay_sinh`, `nguoi_lap_phieu`, `ma_so_phieu`, `so_lan_in_phieu`, `id_hang`, `check_hoc_phi`, `id_nhom`, `loai_dang_ky`, `noi_dang_ky`, `nguoi_duyet`, `trang_thai_duyet`) VALUES
(1, NULL, 'Nguyễn Văn A', '01234', '3344', '2030-01-01', 'DANG_KY', 7, '2025-03-31 13:34:00', 1, 'Trà Vinh', '1989-01-01', NULL, 1, 3, 4, NULL, NULL, 'Nhập trực tiếp', 'Cơ sở 1 (Cửa hàng Nguyễn Trình)', NULL, 'DA_DUYET');

-- --------------------------------------------------------

--
-- Table structure for table `hv_khoa_hoc`
--

DROP TABLE IF EXISTS `hv_khoa_hoc`;
CREATE TABLE IF NOT EXISTS `hv_khoa_hoc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_hang` int(11) NOT NULL,
  `ten_khoa_hoc` varchar(255) NOT NULL,
  `ngay_bat_dau` date NOT NULL,
  `ngay_ket_thuc` date NOT NULL,
  `ghi_chu` text,
  `trang_thai` varchar(255) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `id_hoc_phi` int(11) NOT NULL,
  `so_hoc_vien_khoa_hoc` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_hang_kh_hang` (`id_hang`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hv_khoa_hoc`
--

INSERT INTO `hv_khoa_hoc` (`id`, `id_hang`, `ten_khoa_hoc`, `ngay_bat_dau`, `ngay_ket_thuc`, `ghi_chu`, `trang_thai`, `nguoi_tao`, `thoi_gian_tao`, `id_hoc_phi`, `so_hoc_vien_khoa_hoc`) VALUES
(1, 6, 'Khóa C1 01/4/2025', '2025-04-01', '2025-05-31', '', 'CHUA_HOAN_THANH', 5, '2025-03-30 20:20:06', 30, 100);

-- --------------------------------------------------------

--
-- Table structure for table `hv_nhom`
--

DROP TABLE IF EXISTS `hv_nhom`;
CREATE TABLE IF NOT EXISTS `hv_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_khoa_hoc` int(11) NOT NULL,
  `ten_nhom` varchar(50) NOT NULL,
  `ghi_chu` text,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `so_luong_hoc_vien` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hv_khoa_hoc` (`id_khoa_hoc`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `hv_nop_hoc_phi`
--

DROP TABLE IF EXISTS `hv_nop_hoc_phi`;
CREATE TABLE IF NOT EXISTS `hv_nop_hoc_phi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_hoc_vien` int(11) NOT NULL,
  `so_tien_nop` double NOT NULL,
  `ngay_nop` date NOT NULL,
  `nguoi_thu` int(11) NOT NULL,
  `bien_lai` text,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_hoc_vien_hp_hoc_vien` (`id_hoc_vien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `hv_tai_lieu_khoa_hoc`
--

DROP TABLE IF EXISTS `hv_tai_lieu_khoa_hoc`;
CREATE TABLE IF NOT EXISTS `hv_tai_lieu_khoa_hoc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_khoa_hoc` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` varchar(255) NOT NULL,
  `file_display_name` varchar(255) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_khoa_hoc_tl_khoa_hoc` (`id_khoa_hoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `kho_file`
--

DROP TABLE IF EXISTS `kho_file`;
CREATE TABLE IF NOT EXISTS `kho_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai_file` int(11) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(255) DEFAULT NULL,
  `file_size` varchar(255) DEFAULT NULL,
  `file_display_name` varchar(255) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `doi_tuong` varchar(20) DEFAULT NULL,
  `id_doi_tuong` int(11) NOT NULL,
  `ghi_chu` text,
  PRIMARY KEY (`id`),
  KEY `fk-id_loai_ho_so_loai_ho_so` (`loai_file`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kho_file`
--

INSERT INTO `kho_file` (`id`, `loai_file`, `file_name`, `file_type`, `file_size`, `file_display_name`, `nguoi_tao`, `thoi_gian_tao`, `doi_tuong`, `id_doi_tuong`, `ghi_chu`) VALUES
(28, 102, 'Phieu_DK (1).pdf', 'pdf', '47.4 KB', 'Phieu_DK (1).pdf', 1, '2024-09-18 22:46:59', 'VBDEN', 3, NULL),
(29, 100, 'Phieu_DK (1).pdf', 'pdf', '47.4 KB', 'Phieu_DK (1).pdf', 1, '2024-09-18 23:37:18', 'GIAOVIEN', 16, NULL),
(30, 103, 'DA20TTA - DAT - 07082024.pdf', 'pdf', '94.8 KB', 'Tài liệu học A2', 1, '2024-09-18 23:52:24', 'KHOAHOC', 2, NULL),
(31, 102, 'DATN.docx', 'docx', '5.48 MB', 'DATN', 1, '2024-09-19 14:46:38', 'VBDEN', 1, NULL),
(32, 101, 'DATN.docx', 'docx', '5.48 MB', 'vanbanden', 1, '2024-09-19 14:47:38', 'VBDEN', 1, NULL),
(33, 100, 'Phieu_DK (1).pdf', 'pdf', '47.4 KB', 'Phieu_DK (1).pdf', 1, '2024-09-19 15:11:29', 'GIAOVIEN', 25, NULL),
(34, 103, 'kho_update.pdf', 'pdf', '0.2 MB', 'kho_update.pdf', 1, '2024-09-19 15:11:56', 'KHOAHOC', 1, NULL),
(36, 104, 'kho_update.pdf', 'pdf', '0.2 MB', 'kho_update.pdf', 1, '2024-09-19 15:18:57', 'NHANVIEN', 21, NULL),
(38, 101, 'DATN.docx', 'docx', '5.48 MB', 'DACN1', 1, '2024-09-19 15:37:42', 'VBDEN', 1, NULL),
(39, 10, 'TuVietTat1.docx', 'docx', '15.7 KB', 'TuVietTat.docx', 1, '2024-09-21 09:00:32', 'VBDI', 19, NULL),
(41, 105, 'Phieu_DK.pdf', 'pdf', '47.4 KB', 'Phieu_DK.pdf', 1, '2024-09-23 14:12:59', 'HOCVIEN', 18, NULL),
(42, 100, 'kho_update.pdf', 'pdf', '0.2 MB', 'kho_update.pdf', 1, '2024-09-23 14:13:37', 'GIAOVIEN', 32, NULL),
(43, 10, 'Untitled (12).pdf', 'pdf', '0.26 MB', 'Untitled (12).pdf', 1, '2024-09-23 14:37:01', 'VBDI', 19, NULL),
(44, 101, 'bien_lai.PNG', 'png', '7 KB', 'fffff', 1, '2024-09-23 14:37:38', 'VBDEN', 2, NULL),
(46, 103, 'grid-export (3).pdf', 'pdf', '45.9 KB', 'grid-export (3).pdf', 1, '2024-09-23 14:57:55', 'KHOAHOC', 1, NULL),
(48, 10, 'Phieu_DK (1).pdf', 'pdf', '47.4 KB', 'PhieuDK', 1, '2024-09-23 15:02:29', 'VBDI', 19, NULL),
(49, 9, 'Phieu_DK.pdf', 'pdf', '47.4 KB', 'PhieuDK', 1, '2024-09-23 15:03:46', 'VBDI', 19, NULL),
(50, 101, 'Phieu_DK (1).pdf', 'pdf', '47.4 KB', 'phieudk', 1, '2024-09-23 15:04:26', 'VBDEN', 3, NULL),
(51, 102, 'DA20TTA - DAT - 07082024.pdf', 'pdf', '94.8 KB', 'DA20TTA', 1, '2024-09-23 15:05:17', 'VBDEN', 2, NULL),
(52, 101, 'Untitled (3).pdf', 'pdf', '0.2 MB', 'phieudk1', 1, '2024-09-23 15:05:54', 'VBDEN', 1, NULL),
(53, 102, 'wc1.PNG', 'png', '0.14 MB', 'test', 1, '2024-09-23 15:06:18', 'VBDEN', 1, NULL),
(54, 105, 'MHUD.docx', 'docx', '0.91 MB', 'LýLich3', 1, '2024-09-23 15:07:10', 'HOCVIEN', 18, NULL),
(56, 100, 'DATN.docx', 'docx', '5.48 MB', 'LyLichGV2', 1, '2024-09-23 15:08:37', 'GIAOVIEN', 32, NULL),
(57, 103, 'Phieu_DK (1).pdf', 'pdf', '47.4 KB', 'TaiLieuKHoaHoc2', 1, '2024-09-23 15:10:25', 'KHOAHOC', 2, NULL),
(59, 104, 'Phieu_DK (1).pdf', 'pdf', '47.4 KB', 'Phieu_DK (1).pdf', 1, '2024-09-24 08:35:44', 'NHANVIEN', 39, NULL),
(60, 103, 'DATN.docx', 'docx', '5.48 MB', 'DATN.docx', 1, '2024-09-24 10:47:10', 'KHOAHOC', 3, NULL),
(62, 104, 'Van_ban.pdf', 'pdf', '0.19 MB', 'LyLichNhanVien', 1, '2024-09-24 14:23:47', 'NHANVIEN', 41, NULL),
(63, 103, 'Phieu_DK (1).pdf', 'pdf', '47.4 KB', 'Tài liệu dạy C1', 1, '2024-09-24 14:36:11', 'KHOAHOC', 4, NULL),
(67, 104, 'kho_update.pdf', 'pdf', '0.2 MB', 'LyLichNhanVien', 1, '2024-09-30 08:29:55', 'NHANVIEN', 52, NULL),
(80, 105, 'thong-tin-xe-thue (1).png', 'png', '0.25 MB', 'thong-tin-xe-thue (1).png', 1, '2024-10-25 16:42:02', 'HOCVIEN', 2, NULL),
(81, 9, NULL, NULL, NULL, 'hợp đồng STN', 1, '2025-01-03 16:08:53', 'VBDI', 32, NULL),
(82, 106, 'danh sach be giang ngay 28.12..pdf', 'pdf', '0.27 MB', 'txttt', 1, '2025-01-03 16:09:27', 'VBDI', 32, NULL),
(83, 108, 'danh sach be giang ngay 28.12..pdf', 'pdf', '0.27 MB', 'Hợp đồng ', 1, '2025-01-04 08:25:53', 'PHIEU_TX', 52, NULL),
(84, 109, 'testTKB2.pdf', 'pdf', '22.2 KB', 'Phiếu thu ', 1, '2025-01-04 08:26:39', 'PHIEU_TX', 52, NULL),
(85, 107, 'testTKB.pdf', 'pdf', '94 KB', 'hopdong2', 1, '2025-01-04 08:29:25', 'VBDI', 32, NULL),
(94, 110, 'testTKB2.pdf', 'pdf', '22.2 KB', 'GPLX_HV0038', 1, '2025-01-15 14:59:29', 'GIAY_PHEP_LX', 130, NULL),
(95, 110, 'VI TICH PHAN  A2-chuong 1-2 (1).pdf', 'pdf', '0.59 MB', 'Giấy phép lái xe 002', 1, '2025-02-06 14:05:11', 'GIAY_PHEP_LX', 131, NULL),
(96, 110, 'vanban_update.pdf', 'pdf', '0.19 MB', 'vanbanden', 1, '2025-02-06 14:23:36', 'GIAY_PHEP_LX', 129, NULL),
(97, 108, 'Van_ban.pdf', 'pdf', '0.19 MB', 'HopDongThueXe001', 1, '2025-02-06 14:30:34', 'PHIEU_TX', 41, NULL),
(98, 109, 'Untitled.pdf', 'pdf', '0.23 MB', 'PhieuThu001', 1, '2025-02-06 14:31:00', 'PHIEU_TX', 41, NULL),
(99, 110, 'vanban_update.pdf', 'pdf', '0.19 MB', 'Giấy phép lái xe - Trương Lãng Hách ', 1, '2025-02-10 08:18:42', 'GIAY_PHEP_LX', 120, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `kho_hop`
--

DROP TABLE IF EXISTS `kho_hop`;
CREATE TABLE IF NOT EXISTS `kho_hop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ngan` int(11) NOT NULL,
  `ten_hop` varchar(255) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_ngan_ngan` (`id_ngan`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kho_hop`
--

INSERT INTO `kho_hop` (`id`, `id_ngan`, `ten_hop`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(4, 5, 'Hộp 1 ', 1, '2024-09-25 10:52:38'),
(5, 4, 'Hộp 2 ', 1, '2024-09-25 10:52:45'),
(6, 4, 'Hộp 3', 1, '2024-09-25 10:52:55');

-- --------------------------------------------------------

--
-- Table structure for table `kho_ke`
--

DROP TABLE IF EXISTS `kho_ke`;
CREATE TABLE IF NOT EXISTS `kho_ke` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho` int(11) NOT NULL,
  `ten_ke` varchar(255) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_kho_kho` (`id_kho`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kho_ke`
--

INSERT INTO `kho_ke` (`id`, `id_kho`, `ten_ke`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(3, 7, 'Kệ 1', 1, '2024-09-25 10:50:44'),
(4, 8, 'Kệ 2', 1, '2024-09-25 10:50:54');

-- --------------------------------------------------------

--
-- Table structure for table `kho_kho`
--

DROP TABLE IF EXISTS `kho_kho`;
CREATE TABLE IF NOT EXISTS `kho_kho` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_kho` varchar(255) NOT NULL,
  `so_do_kho` varchar(255) DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kho_kho`
--

INSERT INTO `kho_kho` (`id`, `ten_kho`, `so_do_kho`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(6, 'Kho 1 ', 'images/1727233686_sodokho1.jfif', 1, '2024-09-25 08:43:30'),
(7, 'Kho 2 ', 'images/1727228624_sodokho2.jfif', 1, '2024-09-25 08:43:44'),
(8, 'Kho 3 ', 'images/1727228646_sodokho3.png', 1, '2024-09-25 08:44:06'),
(9, 'Kho 4', 'images/1727228665_sodokho4.jfif', 1, '2024-09-25 08:44:25');

-- --------------------------------------------------------

--
-- Table structure for table `kho_loai_file`
--

DROP TABLE IF EXISTS `kho_loai_file`;
CREATE TABLE IF NOT EXISTS `kho_loai_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_loai` varchar(255) NOT NULL,
  `ho_so_bat_buoc` tinyint(1) NOT NULL,
  `ghi_chu` text,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `doi_tuong` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kho_loai_file`
--

INSERT INTO `kho_loai_file` (`id`, `ten_loai`, `ho_so_bat_buoc`, `ghi_chu`, `nguoi_tao`, `thoi_gian_tao`, `doi_tuong`) VALUES
(9, 'FILEVB', 0, 'File Văn bản', 1, '2024-09-20 09:52:14', 'VBDi'),
(10, 'VBDK', 0, 'Văn bản đính kèm', 1, '2024-08-20 15:22:25', 'VBDI '),
(100, 'Lý lịch giáo viên ', 1, 'Lý lịch giáo viên', 1, '2024-09-18 22:44:21', 'GIAOVIEN'),
(101, 'File VB', 0, 'File văn bản đã ký, vô sổ và scan', 1, '2024-09-18 17:46:10', 'VBDEN'),
(102, 'File Đính kèm VB đến', 0, 'File đính kèm của văn bản', 1, '2024-09-18 17:46:10', 'VBDEN'),
(103, 'File_KH', 0, 'File Tài liệu khóa học', 1, '2024-09-18 18:51:37', 'KHOAHOC'),
(104, 'Lý lịch nhân viên', 1, 'Lý lịch nhân viên file', 1, '2024-09-19 15:18:21', 'NHANVIEN'),
(105, 'Lý lịch học viên ', 1, 'Đây là các file hồ sơ lý lịch học viên', 1, '2024-09-20 14:56:56', 'HOCVIEN'),
(106, 'File VB', 0, 'File văn bản đã ký, vô sổ và scan', 1, '2024-10-02 10:09:30', 'VBDI'),
(107, 'File Đính kèm VB đến', 0, 'File đính kèm của văn bản', 1, '2024-10-02 10:09:30', 'VBDI'),
(108, 'Hợp đồng thuê xe', 1, 'Hợp đồng cho thuê xe ', 1, '2025-01-04 08:21:52', 'PHIEU_TX'),
(109, 'Phiếu thu ', 1, 'Phiếu thu thuê xe ', 1, '2025-01-04 08:21:52', 'PHIEU_TX'),
(110, 'Giấy phép lái xe', 0, 'Giấy phép lái xe học viên khi hoàn thành khóa học', 1, '2025-01-04 08:21:52', 'GIAY_PHEP_LX'),
(111, 'Phiếu đăng ký', 0, '', 4, '2025-03-30 06:19:01', 'HOCVIEN'),
(112, 'Hình ảnh', 0, '', 4, '2025-03-30 06:19:11', 'HOCVIEN');

-- --------------------------------------------------------

--
-- Table structure for table `kho_luu_kho`
--

DROP TABLE IF EXISTS `kho_luu_kho`;
CREATE TABLE IF NOT EXISTS `kho_luu_kho` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai_file` varchar(255) DEFAULT NULL,
  `id_file` int(11) NOT NULL,
  `id_kho` int(11) NOT NULL,
  `id_ke` int(11) NOT NULL,
  `id_ngan` int(11) NOT NULL,
  `id_hop` int(11) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `doi_tuong` varchar(20) DEFAULT NULL,
  `id_doi_tuong` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_kho_luu_kho` (`id_kho`),
  KEY `fk-id_ngan_luu_ngan` (`id_ngan`),
  KEY `fk-id_ke_luu_ke` (`id_ke`),
  KEY `fk-id_hop_luu_hop` (`id_hop`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kho_luu_kho`
--

INSERT INTO `kho_luu_kho` (`id`, `loai_file`, `id_file`, `id_kho`, `id_ke`, `id_ngan`, `id_hop`, `nguoi_tao`, `thoi_gian_tao`, `doi_tuong`, `id_doi_tuong`) VALUES
(5, NULL, 0, 7, 3, 4, 6, 1, '2024-09-25 16:05:22', 'VBDEN', 1),
(6, NULL, 0, 7, 3, 4, 6, 1, '2024-09-25 16:19:47', 'VBDI', 19),
(11, NULL, 0, 8, 4, 5, 4, 1, '2024-09-30 08:30:12', 'NHANVIEN', 52);

-- --------------------------------------------------------

--
-- Table structure for table `kho_ngan`
--

DROP TABLE IF EXISTS `kho_ngan`;
CREATE TABLE IF NOT EXISTS `kho_ngan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ke` int(11) NOT NULL,
  `ten_ngan` varchar(255) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_ke_ke` (`id_ke`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kho_ngan`
--

INSERT INTO `kho_ngan` (`id`, `id_ke`, `ten_ngan`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(4, 3, 'Ngăn 1 ', 1, '2024-09-25 10:52:15'),
(5, 4, 'Ngăn 2 ', 1, '2024-09-25 10:52:21');

-- --------------------------------------------------------

--
-- Table structure for table `lh_ket_qua_thi`
--

DROP TABLE IF EXISTS `lh_ket_qua_thi`;
CREATE TABLE IF NOT EXISTS `lh_ket_qua_thi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_hoc_vien` int(11) NOT NULL,
  `id_lich_thi` int(11) NOT NULL,
  `id_phan_thi` int(11) NOT NULL,
  `diem_so` int(11) NOT NULL,
  `ket_qua` varchar(20) NOT NULL,
  `trang_thai` int(20) DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `lan_thi` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lh_ket_qua_thi`
--

INSERT INTO `lh_ket_qua_thi` (`id`, `id_hoc_vien`, `id_lich_thi`, `id_phan_thi`, `diem_so`, `ket_qua`, `trang_thai`, `nguoi_tao`, `thoi_gian_tao`, `lan_thi`) VALUES
(15, 130, 11, 8, 34, 'ĐẠT', NULL, 1, '2025-01-14 08:59:11', 1),
(16, 130, 11, 16, 35, 'ĐẠT', NULL, 1, '2025-01-14 08:59:43', 1),
(17, 130, 11, 17, 55, 'RỚT', NULL, 1, '2025-01-14 09:00:41', 1),
(18, 130, 11, 17, 85, 'ĐẠT', NULL, 1, '2025-01-14 09:00:59', 2),
(19, 130, 11, 18, 90, 'ĐẠT', NULL, 1, '2025-01-14 09:01:25', 1),
(74, 131, 19, 4, 25, 'ĐẠT', NULL, 1, '2025-01-16 13:53:49', 1),
(75, 131, 19, 6, 90, 'ĐẠT', NULL, 1, '2025-01-16 13:53:57', 1),
(78, 129, 19, 4, 23, 'ĐẠT', NULL, 1, '2025-01-17 10:39:43', 1),
(79, 129, 19, 6, 70, 'RỚT', NULL, 1, '2025-01-17 10:40:02', 1),
(121, 128, 15, 8, 23, 'RỚT', NULL, 1, '2025-02-08 09:50:54', 1),
(122, 128, 15, 8, 35, 'ĐẠT', NULL, 1, '2025-02-08 09:50:54', 2),
(123, 128, 15, 16, 36, 'ĐẠT', NULL, 1, '2025-02-08 10:07:33', 2),
(124, 128, 15, 17, 80, 'ĐẠT', NULL, 1, '2025-02-08 10:07:57', 1),
(125, 128, 15, 18, 95, 'ĐẠT', NULL, 1, '2025-02-08 10:08:30', 1),
(129, 120, 19, 4, 23, 'ĐẠT', NULL, 1, '2025-02-10 08:17:47', 1),
(130, 120, 19, 6, 100, 'ĐẠT', NULL, 1, '2025-02-10 08:17:47', 1);

-- --------------------------------------------------------

--
-- Table structure for table `lh_lich_hoc`
--

DROP TABLE IF EXISTS `lh_lich_hoc`;
CREATE TABLE IF NOT EXISTS `lh_lich_hoc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_khoa_hoc` int(11) NOT NULL,
  `hoc_phan` varchar(25) DEFAULT NULL,
  `id_nhom` int(11) DEFAULT NULL,
  `id_phong` int(11) NOT NULL,
  `id_giao_vien` int(11) NOT NULL,
  `ngay` date NOT NULL,
  `thu` varchar(15) DEFAULT NULL,
  `tiet_bat_dau` int(11) NOT NULL,
  `tiet_ket_thuc` int(11) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lh_khoa_hoc` (`id_khoa_hoc`),
  KEY `lh_giao_vien` (`id_giao_vien`),
  KEY `lh_phong_hoc` (`id_phong`),
  KEY `lh_nhom_hoc` (`id_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `lh_lich_thi`
--

DROP TABLE IF EXISTS `lh_lich_thi`;
CREATE TABLE IF NOT EXISTS `lh_lich_thi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_khoa_hoc` int(11) NOT NULL,
  `id_nhom` int(11) DEFAULT NULL,
  `id_phong_thi` int(11) NOT NULL,
  `id_giao_vien_gac` int(11) NOT NULL,
  `thoi_gian_thi` datetime NOT NULL,
  `trang_thai` varchar(30) DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `ten_ky_thi` varchar(50) NOT NULL,
  `loai_lich_thi` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_khoa_hoc_lich_thi` (`id_khoa_hoc`),
  KEY `fk_nhom_lich_thi` (`id_nhom`),
  KEY `id_phong_thi` (`id_phong_thi`),
  KEY `fk_gvg` (`id_giao_vien_gac`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `lh_phan_thi`
--

DROP TABLE IF EXISTS `lh_phan_thi`;
CREATE TABLE IF NOT EXISTS `lh_phan_thi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_phan_thi` varchar(40) NOT NULL,
  `id_hang` int(11) NOT NULL,
  `diem_dat_toi_thieu` int(11) NOT NULL,
  `trang_thai` varchar(20) DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `thu_tu_thi` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_hang` (`id_hang`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `lh_phong_hoc`
--

DROP TABLE IF EXISTS `lh_phong_hoc`;
CREATE TABLE IF NOT EXISTS `lh_phong_hoc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_phong` varchar(50) NOT NULL,
  `so_do_phong` varchar(255) DEFAULT NULL,
  `ghi_chu` text,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lh_phong_hoc`
--

INSERT INTO `lh_phong_hoc` (`id`, `ten_phong`, `so_do_phong`, `ghi_chu`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(1, 'A01.202', NULL, 'Phòng học lý thuyết ', 1, '2024-11-28 10:43:02'),
(4, 'A11.301', 'images/1732765539_TKB4.png', 'Phòng thiết bị ', 1, '2024-11-28 10:45:39'),
(5, 'A11.300', 'images/1732765582_TKB3.png', 'Phòng văn thư tổng hợp', 1, '2024-11-28 10:46:22');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1724233955),
('m140608_173539_create_user_table', 1724233956),
('m140611_133903_init_rbac', 1724233957),
('m140808_073114_create_auth_item_group_table', 1724233957),
('m140809_072112_insert_superadmin_to_user', 1724233958),
('m140809_073114_insert_common_permisison_to_auth_item', 1724233958),
('m141023_141535_create_user_visit_log', 1724233958),
('m141116_115804_add_bind_to_ip_and_registration_ip_to_user', 1724233958),
('m141121_194858_split_browser_and_os_column', 1724233959),
('m141201_220516_add_email_and_email_confirmed_to_user', 1724233959),
('m141207_001649_create_basic_user_permissions', 1724233959),
('m240802_013852_create_table_vb_van_ban', 1724233999),
('m240802_014513_create_table_vb_dm_loai_vb', 1724233999),
('m240802_014950_create_table_vb_file_van_ban', 1724233999),
('m240802_020203_create_table_vb_vb_dinh_kem', 1724233999),
('m240802_021844_create_table_hv_hoc_vien', 1724233999),
('m240802_022237_create_table_hv_loai_ho_so', 1724233999),
('m240802_023155_create_table_hv_ho_so_hoc_vien', 1724233999),
('m240802_023954_create_table_hv_khoa_hoc', 1724233999),
('m240802_024906_create_table_hv_tai_lieu_khoa_hoc', 1724233999),
('m240802_030706_create_table_hv_hang_dao_tao', 1724233999),
('m240802_031118_create_table_hv_hoc_phi', 1724233999),
('m240802_032646_create_table_hv_nop_hoc_phi', 1724233999),
('m240802_033557_create_table_nv_nhan_vien', 1724233999),
('m240802_073745_create_table_nv_phong_ban', 1724233999),
('m240802_075440_create_table_nv_day', 1724234000),
('m240802_080029_create_table_nv_hang_xe', 1724234000),
('m240802_080455_create_table_nv_ho_so_nhan_vien', 1724234000),
('m240802_081800_create_table_kho_kho', 1724234000),
('m240802_082755_create_table_kho_ke', 1724234000),
('m240802_083016_create_table_kho_ngan', 1724234000),
('m240802_083217_create_table_kho_hop', 1724234000),
('m240802_083745_create_table_kho_luu_kho', 1724234000),
('m240803_021934_them_cot_nguoi_tao_thoi_gian_tao', 1724234001),
('m240803_081331_them_fk', 1724234003),
('m240814_010353_upload_fk_nhan_vien', 1724234003),
('m240814_035312_table_nv_to', 1724234003),
('m240819_072431_field_id_to', 1724234003),
('m240819_072847_fk_nv_to', 1724234004),
('m240819_073000_field_male', 1724234004),
('m240819_073110_loai_hs_doi_tuong', 1724234004),
('m240819_073210_insert_loai_so_vb', 1724234004),
('m240820_010725_update_table_loai_ho_so', 1724234004),
('m240820_020610_delete_table_ho_so_hv', 1724234004),
('m240820_021217_rename_table_ho_so_nv', 1724234004),
('m240821_145941_delete_fk_kho_hs', 1724252804),
('m240821_150840_delete_id_nhan_vien', 1724253009),
('m240821_151135_insert_field_doi_tuong', 1724253179),
('m240821_151408_insert_field_nam_vb', 1724253395),
('m240821_151738_field_nam_vb', 1724253558),
('m240821_152126_field_nam_van_ban', 1724254399),
('m240821_152126_field_nam_vb', 1724253775),
('m240823_023001_ins_field_', 1724380441),
('m240823_074711_update_loai_hs', 1724399571),
('m240823_075003_update_name_table_ho_so', 1724399571),
('m240823_080630_delete_fk', 1724400996),
('m240823_082025_delete_fk_file_vb', 1724401302),
('m240823_082246_delete_fk_vb_dinh_kem', 1724401497),
('m240823_082547_table_file_vb_vb_dk', 1724401613),
('m240823_085057_upload', 1724403280),
('m240823_085726_upload', 1724403598),
('m240823_090110_update_kho_file', 1724403729),
('m240824_010920_rename_field', 1724462016),
('m240824_010920_rename_field_loai', 1724462157),
('m240824_011738_rename_field_id_loai_hs', 1724462356),
('m240827_014150_update_table_hv', 1724723450),
('m240828_030305_insert_field_ngay_sinh', 1724814320),
('m240829_012439_insert_field_fullname', 1724894913),
('m240829_014533_insert_fullname', 1724896058),
('m240829_015153_field_fullname', 1724896369),
('m240829_024157_insert_field_lap_phieu', 1724899497),
('m240829_024157_insert_field_nguoi_lap_phieu', 1724899736),
('m240830_011942_insert_field_hang', 1724980868),
('m240830_013148_insert_fk_id_hang', 1724981798),
('m240830_023719_update_id_khoa_hoc', 1724985960),
('m240904_022612_update_field_bien_lai', 1725416967),
('m240905_013104_update_kho_file', 1725500104),
('m240907_031153_delete_nv_hang_xe', 1725679680),
('m240907_034238_insert_fk_nv_day', 1725680865),
('m240917_034238_insert_data_for_loai_file', 1726674370),
('m240918_164816_insert_date_loai_file_khoa_hoc', 1726678297),
('m240919_014303_insert_data_phong_ban', 1726710857),
('m240919_015515_insert_data_to', 1726711617),
('m240919_021508_insert_data_hv_dang_ky', 1726712563),
('m240920_020751_update_table_kho_luu_kho', 1726798728),
('m240923_031204_insert_field_check_dt_nhan_vien', 1727061289),
('m240923_032341_update_field_doi_tuong_nv', 1727062012),
('m240923_033607_update_nv_nhan_vien', 1727062766),
('m240923_071745_insert_luukho_id_doi_tuong', 1727075944),
('m240923_072019_table_chuc_vu', 1727076214),
('m240923_072818_insert_field_tb_nv_chuc_vu', 1727076732),
('m240924_024338_delete_data_doi_tuong', 1727145840),
('m240924_024601_update_field_doi_tuong_nv', 1727510605),
('m240924_024707_update_nv_nhan_vien', 1727510605),
('m241001_034238_insert_data_for_loai_file_van_ban_di', 1727856570),
('m241002_011738_rename_field_vbden_so_den', 1727856570),
('m241008_072205_insert_field_check_hoc_phi', 1728372535),
('m241008_074947_update_table_nop_hoc_phi', 1728374098),
('m241021_012953_create_table_ptx_phieu_thue_xe', 1729476292),
('m241021_020732_create_table_ptx_loai_hinh_thue', 1729477050),
('m241021_021827_create_table_ptx_xe', 1729477337),
('m241021_022400_insert_field_table_ptx_xe_', 1729477639),
('m241021_022839_create', 1729477986),
('m241021_023732_insert_fk_ptx', 1729479205),
('m241021_084028_insert_field_dang_ap_dung', 1729500257),
('m241030_080645_create_table_nop_phi_thue_xe', 1730276436),
('m241219_034709_insert_field_hoc_vien', 1734580502),
('m250329_000001_insert_auth_item_group_data', 1743305419),
('m250329_000002_insert_auth_item_data', 1743305419),
('m250329_000003_insert_auth_item_child_data', 1743305419),
('m250329_000004_insert_role_data', 1743305419),
('m250330_000001_insert_field_ho_ten_to_user', 1743311121);

-- --------------------------------------------------------

--
-- Table structure for table `nv_chuc_vu`
--

DROP TABLE IF EXISTS `nv_chuc_vu`;
CREATE TABLE IF NOT EXISTS `nv_chuc_vu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_chuc_vu` varchar(55) NOT NULL,
  `ghi_chu` text,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `nv_day`
--

DROP TABLE IF EXISTS `nv_day`;
CREATE TABLE IF NOT EXISTS `nv_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_nhan_vien` int(11) NOT NULL,
  `id_hang_xe` int(11) NOT NULL,
  `ly_thuyet` tinyint(1) NOT NULL,
  `thuc_hanh` tinyint(1) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_nhan_vien_day_nhan_vien` (`id_nhan_vien`),
  KEY `fk-id_hang_xe_hang_xe` (`id_hang_xe`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `nv_nhan_vien`
--

DROP TABLE IF EXISTS `nv_nhan_vien`;
CREATE TABLE IF NOT EXISTS `nv_nhan_vien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_phong_ban` int(11) DEFAULT NULL,
  `ho_ten` varchar(255) NOT NULL,
  `chuc_vu` text,
  `so_cccd` varchar(255) DEFAULT NULL,
  `dia_chi` varchar(255) DEFAULT NULL,
  `dien_thoai` varchar(255) DEFAULT NULL,
  `tai_khoan` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `trinh_do` text,
  `chuyen_nganh` varchar(255) DEFAULT NULL,
  `vi_tri_cong_viec` varchar(255) DEFAULT NULL,
  `kinh_nghiem_lam_viec` text,
  `ma_so_thue` varchar(255) DEFAULT NULL,
  `trang_thai` varchar(255) DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `id_to` int(11) DEFAULT NULL,
  `gioi_tinh` int(11) DEFAULT NULL,
  `doi_tuong` tinyint(3) DEFAULT NULL,
  `ngay_sinh` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-tai_khoan_user` (`tai_khoan`),
  KEY `fk-id_phong_ban_nv` (`id_phong_ban`),
  KEY `fk-id_to_nv` (`id_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `nv_phong_ban`
--

DROP TABLE IF EXISTS `nv_phong_ban`;
CREATE TABLE IF NOT EXISTS `nv_phong_ban` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_phong_ban` varchar(255) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nv_phong_ban`
--

INSERT INTO `nv_phong_ban` (`id`, `ten_phong_ban`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(1, 'Phòng Tài chính - Kế toán', NULL, NULL),
(2, 'Phòng Kế hoạch - Đào tạo', NULL, NULL),
(3, 'Phòng Hành chính - Tổng hợp', NULL, NULL),
(24, 'Phòng KInh tế ', 1, '2025-01-18 14:58:59'),
(25, 'Phòng Lễ Tân ', 1, '2025-01-18 14:59:49'),
(26, 'Phòng Bảo Vệ ', 1, '2025-01-18 15:47:03');

-- --------------------------------------------------------

--
-- Table structure for table `nv_to`
--

DROP TABLE IF EXISTS `nv_to`;
CREATE TABLE IF NOT EXISTS `nv_to` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_phong_ban` int(11) DEFAULT NULL,
  `ten_to` varchar(255) NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_phong_ban_to` (`id_phong_ban`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nv_to`
--

INSERT INTO `nv_to` (`id`, `id_phong_ban`, `ten_to`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(1, 2, 'Giáo vụ', NULL, NULL),
(2, 3, 'Văn thư', NULL, NULL),
(13, 24, 'Đấu thầu ', 1, '2025-01-18 15:33:28'),
(14, 25, 'Lễ Tân ', 1, '2025-01-18 15:47:24');

-- --------------------------------------------------------

--
-- Table structure for table `ptx_hinh_xe`
--

DROP TABLE IF EXISTS `ptx_hinh_xe`;
CREATE TABLE IF NOT EXISTS `ptx_hinh_xe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_xe` int(11) NOT NULL,
  `hinh_anh` text NOT NULL,
  `nguoi_tao` int(11) NOT NULL,
  `thoi_gian_tao` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ptx_hinh_xe`
--

INSERT INTO `ptx_hinh_xe` (`id`, `id_xe`, `hinh_anh`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(38, 1, '6743de6b005e7.jfif', 1, '2024-11-25 09:18:26'),
(39, 1, '6743de6c65867.jfif', 1, '2024-11-25 09:18:26'),
(46, 2, '6743de9a7b39a.jfif', 1, '2024-11-25 09:19:22');

-- --------------------------------------------------------

--
-- Table structure for table `ptx_loai_hinh_thue`
--

DROP TABLE IF EXISTS `ptx_loai_hinh_thue`;
CREATE TABLE IF NOT EXISTS `ptx_loai_hinh_thue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai_hinh_thue` varchar(20) NOT NULL,
  `id_loai_xe` int(11) NOT NULL,
  `gia_thue` double NOT NULL,
  `ngay_ap_dung` date NOT NULL,
  `ngay_ket_thuc` date NOT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `dang_ap_dung` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-loai_xe` (`id_loai_xe`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ptx_loai_hinh_thue`
--

INSERT INTO `ptx_loai_hinh_thue` (`id`, `loai_hinh_thue`, `id_loai_xe`, `gia_thue`, `ngay_ap_dung`, `ngay_ket_thuc`, `nguoi_tao`, `thoi_gian_tao`, `dang_ap_dung`) VALUES
(1, 'Giờ ', 1, 500000, '2024-10-01', '2024-10-31', 1, '2024-10-21 16:12:36', 1),
(2, 'Ngày ', 1, 1000000, '2024-10-02', '2024-10-31', 1, '2024-10-22 16:11:19', 1),
(3, 'Buổi ', 1, 700000, '2024-10-02', '2024-10-31', 1, '2024-10-22 16:12:05', 1),
(4, 'Giờ ', 3, 300000, '2024-10-16', '2024-10-24', 1, '2024-10-24 09:19:07', 1),
(5, 'Giờ ', 2, 700000, '2024-10-16', '2024-10-31', 1, '2024-10-28 08:20:48', 1),
(6, '1 Ngày 1 Đêm ', 1, 2500000, '2024-11-14', '2024-11-30', 1, '2024-11-11 16:27:39', 1),
(7, 'Đêm ', 1, 700000, '2024-11-13', '2024-11-30', 1, '2024-11-12 08:55:23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ptx_loai_xe`
--

DROP TABLE IF EXISTS `ptx_loai_xe`;
CREATE TABLE IF NOT EXISTS `ptx_loai_xe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_loai_xe` varchar(50) NOT NULL,
  `ghi_chu` text,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ptx_loai_xe`
--

INSERT INTO `ptx_loai_xe` (`id`, `ten_loai_xe`, `ghi_chu`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(1, 'Xe tải 4 bánh ', 'Xe tải 4 bánh ', NULL, NULL),
(2, 'Xe Khách 16 chỗ ', 'Xe khách dùng để dạy B2 ', NULL, NULL),
(3, 'Xe tải 6 bánh ', 'Xe tải 6 bánh ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ptx_muon_xe`
--

DROP TABLE IF EXISTS `ptx_muon_xe`;
CREATE TABLE IF NOT EXISTS `ptx_muon_xe` (
  `id` int(11) NOT NULL,
  `thoi_gian_muon` datetime NOT NULL,
  `id_nguoi_muon` int(11) NOT NULL,
  `ghi_chu_nguoi_muon` text NOT NULL,
  `id_xe_muon` int(11) NOT NULL,
  `id_nguoi_duyet` int(11) NOT NULL,
  `ghi_chu_nguoi_duyet` text NOT NULL,
  `thoi_gian_duyet` datetime NOT NULL,
  `thoi_gian_tra` datetime NOT NULL,
  `thoi_gian_tra_du_kien` datetime NOT NULL,
  `trang_thai` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ptx_nop_phi_thue_xe`
--

DROP TABLE IF EXISTS `ptx_nop_phi_thue_xe`;
CREATE TABLE IF NOT EXISTS `ptx_nop_phi_thue_xe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_phieu_thue_xe` int(11) DEFAULT NULL,
  `id_hoc_vien` int(11) DEFAULT NULL,
  `ho_ten_nguoi_thue` varchar(50) DEFAULT NULL,
  `so_cccd_nguoi_thue` varchar(15) DEFAULT NULL,
  `dia_chi_nguoi_thue` varchar(255) DEFAULT NULL,
  `so_dien_thoai_nguoi_thue` varchar(12) DEFAULT NULL,
  `so_tien_nop` double DEFAULT NULL,
  `nguoi_thu` int(11) DEFAULT NULL,
  `bien_lai` text,
  `ngay_nop` date DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `trang_thai` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ptx_nop_phi_thue_xe`
--

INSERT INTO `ptx_nop_phi_thue_xe` (`id`, `id_phieu_thue_xe`, `id_hoc_vien`, `ho_ten_nguoi_thue`, `so_cccd_nguoi_thue`, `dia_chi_nguoi_thue`, `so_dien_thoai_nguoi_thue`, `so_tien_nop`, `nguoi_thu`, `bien_lai`, `ngay_nop`, `nguoi_tao`, `thoi_gian_tao`, `trang_thai`) VALUES
(4, 31, 82, NULL, NULL, NULL, NULL, 3500000, 34, 'uploads/bien_lai/1730446691_thong-tin-xe-thue.png', '2024-11-27', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(5, 31, 82, NULL, NULL, NULL, NULL, 700000, 34, 'uploads/bien_lai/1730446770_so-sanh-doanh-so-cho-thue-xe.png', '2024-11-15', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(9, 27, 66, NULL, NULL, NULL, NULL, 500000, 34, 'uploads/bien_lai/1730449837_HA2.png', '2024-11-10', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(10, 28, 80, NULL, NULL, NULL, NULL, 700000, 36, 'uploads/bien_lai/1730452589_HA2.png', '2024-11-19', 1, '0000-00-00 00:00:00', ''),
(11, 32, 81, NULL, NULL, NULL, NULL, 1400000, 35, 'uploads/bien_lai/1730452725_HA1.png', '2024-11-19', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(12, 32, 81, NULL, NULL, NULL, NULL, 700000, 34, 'uploads/bien_lai/1730453157_bien-nhan-tra-xe-thue.png', '2024-11-12', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(13, 33, 83, NULL, NULL, NULL, NULL, 700000, 36, 'uploads/bien_lai/1730453773_giao-dich-tien-tai-chinh.png', '2024-11-19', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(14, 33, 83, NULL, NULL, NULL, NULL, 700000, 34, 'uploads/bien_lai/1730517512_bien-nhan-tra-xe-thue.png', '2024-11-02', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(15, 33, 83, NULL, NULL, NULL, NULL, 700000, 34, 'uploads/bien_lai/1730519336_HA2.png', '2024-11-12', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(16, 34, 79, NULL, NULL, NULL, NULL, 1400000, 34, 'uploads/bien_lai/1730519598_HA3.png', '2024-11-13', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(17, 37, NULL, 'Phan Thúy Lan ', '8437501234  ', 'Cồn Cù, Duyên Hải, Trà Vinh  ', '0977553274 ', 1400000, 35, 'uploads/bien_lai/1730683628_cho-thue-xe.png', '2024-11-19', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(18, 37, NULL, 'Phan Thúy Lan ', '8437501234  ', 'Cồn Cù, Duyên Hải, Trà Vinh  ', '0977553274 ', 700000, 34, 'uploads/bien_lai/1730683702_bienlai2.jfif', '2024-11-13', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(19, 38, NULL, 'Phan Thị Thảo Ngân ', '8437501234  ', 'Phường 9, tp.Trà Vinh ', '09667753311 ', 2500000, 34, 'uploads/bien_lai/1730688724_thong-tin-xe-thue (1) (1).png', '2024-11-12', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(20, 39, 84, NULL, NULL, NULL, NULL, 1400000, 36, 'uploads/bien_lai/1730709133_HA1.png', '2024-11-13', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(21, 39, 84, NULL, NULL, NULL, NULL, 700000, 34, 'uploads/bien_lai/1730709231_so-sanh-doanh-so-cho-thue-xe.png', '2024-11-13', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(22, 20, NULL, 'Nguyễn Thị Mộng Thi', '8404503237', 'Cồn Cù, Duyên Hải, Trà Vinh', '0922771332', NULL, 33, 'uploads/bien_lai/1730771067_thong-tin-xe-thue (1) (1).png', '2024-11-12', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(23, 41, NULL, 'Phan Trường An ', '8404503237  ', 'P6, tp Trà Vinh ', '0977553274', 700000, 36, 'uploads/bien_lai/1730858519_thong-tin-xe-thue.png', '2024-11-20', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(24, 41, NULL, 'Phan Trường An ', '8404503237  ', 'P6, tp Trà Vinh ', '0977553274', 700000, 35, 'uploads/bien_lai/1730858542_HA3.png', '2024-11-21', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(25, 41, NULL, 'Phan Trường An ', '8404503237  ', 'P6, tp Trà Vinh ', '0977553274', 400000, 35, 'uploads/bien_lai/1730859723_thong-tin-xe-thue.png', '2024-11-27', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(26, 41, NULL, 'Phan Trường An ', '8404503237  ', 'P6, tp Trà Vinh ', '0977553274', 300000, 33, 'uploads/bien_lai/1730860429_thong-ke-luot-thue-xe.png.pagespeed.ce.AlvKFW_l5n.png', '2024-11-15', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(27, 42, 85, NULL, NULL, NULL, NULL, 300000, 36, 'uploads/bien_lai/1730860725_thong-tin-xe-thue.png', '2024-11-20', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(28, 42, 85, NULL, NULL, NULL, NULL, 300000, 33, 'uploads/bien_lai/1730860767_so-sanh-doanh-so-cho-thue-xe.png', '2024-11-20', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(29, 42, 85, NULL, NULL, NULL, NULL, 300000, 42, 'uploads/bien_lai/1730861155_HA1.png', '2024-11-13', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(30, 44, NULL, 'Nguyễn Thị Cẩm Nhung ', '8437501231', 'P9, tp Trà Vinh ', '0922733514', 800000, 35, 'uploads/bien_lai/1730950670_z6000459079645_6cfc36040747b198dfee1e37d311a434.jpg', '2024-11-20', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(31, 44, NULL, 'Nguyễn Thị Cẩm Nhung ', '8437501231', 'P9, tp Trà Vinh ', '0922733514', 600000, 35, 'uploads/bien_lai/1730964149_bienlai2.jfif', '2024-11-13', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(32, 45, NULL, 'Phạm Thị Ngọc Quỳnh ', '8437501238', 'Hòa Hảo, Châu Thành, Trà Vinh  ', '0977553272', 700000, 49, 'uploads/bien_lai/1730964544_giao-dich-tien-tai-chinh.png', '2024-11-15', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(33, 45, NULL, 'Phạm Thị Ngọc Quỳnh ', '8437501238', 'Hòa Hảo, Châu Thành, Trà Vinh  ', '0977553272', 400000, 54, 'uploads/bien_lai/1731029254_z6000459079645_6cfc36040747b198dfee1e37d311a434.jpg', '2024-11-12', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(34, 44, NULL, 'Nguyễn Thị Cẩm Nhung ', '8437501231', 'P9, tp Trà Vinh ', '0922733514', 500000, 46, 'uploads/bien_lai/1731030242_HA3.png', '2024-11-15', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(36, 45, NULL, 'Phạm Thị Ngọc Quỳnh ', '8437501238', 'Hòa Hảo, Châu Thành, Trà Vinh  ', '0977553272', 300000, 35, 'uploads/bien_lai/1731051744_thong-tin-xe-thue.png', '2024-11-13', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(37, 44, NULL, 'Nguyễn Thị Cẩm Nhung ', '8437501231', 'P9, tp Trà Vinh ', '0922733514', 200000, 36, 'uploads/bien_lai/1731051818_Untitled.png', '2024-11-13', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(38, 43, NULL, 'Phạm Huyền Trân ', '8404503231', 'Hòa Hảo, Châu Thành, Trà Vinh ', '0977553272', 1000000, 46, 'uploads/bien_lai/1731052575_bien-nhan-tra-xe-thue.png', '2024-11-26', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(39, 43, NULL, 'Phạm Huyền Trân ', '8404503231', 'Hòa Hảo, Châu Thành, Trà Vinh ', '0977553272', 500000, 34, 'uploads/bien_lai/1731052661_HA1.png', '2024-11-15', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(40, 43, NULL, 'Phạm Huyền Trân ', '8404503231', 'Hòa Hảo, Châu Thành, Trà Vinh ', '0977553272', 1300000, 55, 'uploads/bien_lai/1731052753_bienlai2.jfif', '2024-11-16', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(41, 43, NULL, 'Phạm Huyền Trân ', '8404503231', 'Hòa Hảo, Châu Thành, Trà Vinh ', '0977553272', 800000, 44, 'uploads/bien_lai/1731053021_bienlai3.jfif', '2024-11-07', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(42, 43, NULL, 'Phạm Huyền Trân ', '8404503231', 'Hòa Hảo, Châu Thành, Trà Vinh ', '0977553272', 600000, 34, 'uploads/bien_lai/1731053124_Thiết kế chưa có tên.jpg', '2024-11-08', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(43, 46, 86, NULL, NULL, NULL, NULL, 1000000, 49, 'uploads/bien_lai/1731055540_bien-nhan-tra-xe-thue.png', '2024-11-13', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(44, 40, NULL, 'Nguyễn Huế Trân ', '8437501232', 'Phường 9, tp.Trà Vinh ', '09667753311 ', 700000, 36, 'uploads/bien_lai/bien_lai_67316339a265e.jpg', '2024-11-12', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(45, 40, NULL, 'Nguyễn Huế Trân ', '8437501232', 'Phường 9, tp.Trà Vinh ', '09667753311 ', 700000, 34, 'uploads/bien_lai/1731290096_bienlai3.jfif', '2024-11-12', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(46, 48, NULL, 'Trần Thị Thùy Linh ', '8404503239', 'P7, tp Trà Vinh ', '0922771552', 1000000, 35, 'uploads/bien_lai/bien_lai_673e9c7423068.jpg', '2024-11-14', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(47, 50, NULL, 'Trần Lưu Quang ', '8407501232  ', 'Hòa Hảo, Châu Thành, Trà Vinh    ', '0922771552 ', 700000, 36, 'uploads/bien_lai/bien_lai_67414bd29540f.jpg', '2024-11-19', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(48, 50, NULL, 'Trần Lưu Quang ', '8407501232  ', 'Hòa Hảo, Châu Thành, Trà Vinh    ', '0922771552 ', 500000, 36, 'uploads/bien_lai/1732332615_20111.png', '2024-11-20', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(49, 52, NULL, 'Nguyễn Khắc Quốc ', '8404503239 ', 'Hòa Hảo, Châu Thành, Trà Vinh    ', '0977553274 ', 700000, 35, 'uploads/bien_lai/bien_lai_6743d56178511.jpg', '2024-11-15', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(50, 51, NULL, 'Nguyễn Ngọc Băng Nhi ', '8404503237  ', 'P7, tp Trà Vinh  ', '0922733514 ', 700000, 35, 'uploads/bien_lai/bien_lai_6743d611ca578.jpg', '2024-11-15', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(51, 49, NULL, 'Dương Phước Lộc', '8404503239', 'Hòa Hảo, Châu Thành, Trà Vinh   ', '0922733514 ', 700000, 36, 'uploads/bien_lai/bien_lai_6743e0aa230b3.jpg', '2024-11-25', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(52, 53, NULL, 'Trần Hữu Lượng ', '8404503239 ', 'Hòa Hảo, Châu Thành, Trà Vinh   ', '0977553271  ', 700000, 36, 'uploads/bien_lai/bien_lai_6744236b908fb.jpg', '2024-11-16', 1, '0000-00-00 00:00:00', 'Phí thuê xe'),
(53, 53, NULL, 'Trần Hữu Lượng ', '8404503239 ', 'Hòa Hảo, Châu Thành, Trà Vinh   ', '0977553271  ', 500000, 36, 'uploads/bien_lai/bien_lai_674423e3ea400.jpg', '2024-11-19', 1, '0000-00-00 00:00:00', 'Phí phát sinh'),
(54, 47, 88, NULL, NULL, NULL, NULL, 1400000, 35, 'uploads/bien_lai/bien_lai_67442b1b12b28.jpg', '2024-11-20', 1, '0000-00-00 00:00:00', 'Phí thuê xe');

-- --------------------------------------------------------

--
-- Table structure for table `ptx_phieu_thue_xe`
--

DROP TABLE IF EXISTS `ptx_phieu_thue_xe`;
CREATE TABLE IF NOT EXISTS `ptx_phieu_thue_xe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ngay_thue_xe` date DEFAULT NULL,
  `id_hoc_vien` int(11) DEFAULT NULL,
  `ho_ten_nguoi_thue` varchar(255) DEFAULT NULL,
  `so_cccd_nguoi_thue` varchar(255) DEFAULT NULL,
  `dia_chi_nguoi_thue` varchar(255) DEFAULT NULL,
  `so_dien_thoai_nguoi_thue` varchar(255) DEFAULT NULL,
  `id_xe` int(11) NOT NULL,
  `id_loai_hinh_thue` int(11) DEFAULT NULL,
  `thoi_gian_bat_dau_thue` datetime DEFAULT NULL,
  `thoi_gian_tra_xe_du_kien` datetime DEFAULT NULL,
  `chi_phi_thue_du_kien` double DEFAULT NULL,
  `thoi_gian_tra_xe` datetime DEFAULT NULL,
  `chi_phi_thue_phat_sinh` double DEFAULT NULL,
  `id_nhan_vien_cho_thue` int(11) DEFAULT NULL,
  `noi_dung_thue` text,
  `ngay_tra_xe` date DEFAULT NULL,
  `tinh_trang_xe_khi_tra` text,
  `id_nhan_vien_ky_tra` int(11) DEFAULT NULL,
  `id_nguoi_gui` int(11) DEFAULT NULL,
  `thoi_gian_gui` datetime DEFAULT NULL,
  `ghi_chu_nguoi_gui` text,
  `id_nguoi_duyet` int(11) DEFAULT NULL,
  `thoi_gian_duyet` datetime DEFAULT NULL,
  `ghi_chu_nguoi_duyet` varchar(255) DEFAULT NULL,
  `trang_thai` varchar(25) DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `buoi` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_xe` (`id_xe`),
  KEY `fk-loai_hinh_thue` (`id_loai_hinh_thue`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ptx_phieu_thue_xe`
--

INSERT INTO `ptx_phieu_thue_xe` (`id`, `ngay_thue_xe`, `id_hoc_vien`, `ho_ten_nguoi_thue`, `so_cccd_nguoi_thue`, `dia_chi_nguoi_thue`, `so_dien_thoai_nguoi_thue`, `id_xe`, `id_loai_hinh_thue`, `thoi_gian_bat_dau_thue`, `thoi_gian_tra_xe_du_kien`, `chi_phi_thue_du_kien`, `thoi_gian_tra_xe`, `chi_phi_thue_phat_sinh`, `id_nhan_vien_cho_thue`, `noi_dung_thue`, `ngay_tra_xe`, `tinh_trang_xe_khi_tra`, `id_nhan_vien_ky_tra`, `id_nguoi_gui`, `thoi_gian_gui`, `ghi_chu_nguoi_gui`, `id_nguoi_duyet`, `thoi_gian_duyet`, `ghi_chu_nguoi_duyet`, `trang_thai`, `nguoi_tao`, `thoi_gian_tao`, `buoi`) VALUES
(20, '2024-10-02', NULL, 'Nguyễn Thị Mộng Thi', '8404503237', 'Cồn Cù, Duyên Hải, Trà Vinh', '0922771332', 1, 1, '2024-07-10 09:50:59', '1970-01-01 08:00:00', NULL, NULL, NULL, 36, 'Thuê xe chở hàng ', NULL, NULL, NULL, 1, '0000-00-00 00:00:00', 'Duyệt gấp !', 1, '2024-10-25 09:25:19', NULL, 'Đã duyệt', 1, '2024-10-24 16:20:07', ''),
(27, '2024-10-15', 66, '', '', '', '', 1, 1, '2024-10-15 05:00:23', '2024-10-15 07:00:23', 1000000, '2024-10-15 08:00:40', 500000, 32, 'Thuê xe tập lái ', '2024-11-10', 'Bình thường ', 33, 1, '0000-00-00 00:00:00', 'Đối với các trường hợp kéo dài, bác sĩ có thể sử dụng các loại thuốc điều trị. Sử dụng thực phẩm chức năng tạo xơ như Metamucil hoặc Citrucel. Điều trị bằng thuốc làm mềm phân như Docusat để phân dễ di chuyển trong ống ruột. Thuốc bôi trơn để bơm hậu môn làm giảm các tác động của phân lên niêm mạc ống hậu môn như Norgalax, Cascara,... Thuốc trị táo bón bằng cách kích thích ruột co bóp như Bisacodyl, Microlax,... để đẩy phân ra ngoài. Thuốc tăng khả năng thẩm thấu để kích thích nhu động ruột như Lactulose,....', 1, '2024-10-31 08:05:53', 'Duyệt', 'Đã trả', 1, '2024-10-26 15:06:49', ''),
(31, '2024-10-15', 82, '', '', '', '', 3, 5, '2024-10-15 01:00:00', '2024-10-15 06:00:00', 3500000, '2024-10-15 07:00:29', 700000, 34, 'Thuê xe tập lái ', '2024-11-13', 'Bình thường ', 35, 1, '0000-00-00 00:00:00', 'Duyệt gấp ', 1, '2024-10-30 16:08:39', 'Đủ điều kiện duyệt ', 'Đã trả', 1, '2024-10-30 15:38:32', ''),
(32, '2024-11-12', 81, '', '', '', '', 3, 5, '2024-11-12 13:00:54', '2024-11-12 15:00:54', 1400000, '2024-11-12 16:00:57', 700000, 33, 'Thuê xe tập lái ', '2024-11-12', 'Bình thường ', 33, 1, '0000-00-00 00:00:00', 'Yêu cầu duyệt phiếu ', 1, '2024-11-01 16:18:10', 'Duyệt ', 'Đã trả', 1, '2024-11-01 16:17:41', ''),
(37, '2024-11-13', NULL, 'Phan Thúy Lan ', '8437501234  ', 'Cồn Cù, Duyên Hải, Trà Vinh  ', '0977553274 ', 3, 5, '2024-11-13 05:00:43', '2024-11-13 07:00:43', 1400000, '2024-11-13 08:00:28', 700000, 35, 'Thuê xe di chuyển ', '2024-11-13', 'Bình thường ', 33, 1, '2024-11-02 14:42:41', 'Gửi phiếu ', 1, '2024-11-02 14:42:55', 'Duyệt phiếu ', 'Đã trả', 1, '2024-11-02 14:42:23', ''),
(38, '2024-11-13', NULL, 'Phan Thị Thảo Ngân ', '8437501234  ', 'Phường 9, tp.Trà Vinh ', '09667753311 ', 1, 1, '2024-11-13 10:00:11', '2024-11-13 15:00:11', 2500000, '2024-11-13 15:00:58', 0, 43, 'Thuê xe tập láy ', '2024-11-13', 'Bình thường ', 34, 1, '2024-11-04 09:43:22', 'Gửi phiếu ', 1, '2024-11-04 09:43:31', 'Ok', 'Đã trả', 1, '2024-11-02 15:56:54', ''),
(39, '2024-11-13', 84, '', '', '', '', 3, 5, '2024-11-13 05:00:45', '2024-11-13 07:00:46', 1400000, '2024-11-13 08:00:04', 700000, 35, 'Thuê xe tập láy ', '2024-11-13', 'Bình thường ', 34, 1, '2024-11-04 15:31:36', 'Gửi phiếu ', 1, '2024-11-04 15:31:54', 'Duyệt ', 'Đã trả', 1, '2024-11-04 15:31:21', ''),
(40, '2024-11-13', NULL, 'Nguyễn Huế Trân ', '8437501232', 'Phường 9, tp.Trà Vinh ', '09667753311 ', 3, 5, '2024-11-12 09:00:23', '2024-11-12 10:00:24', 700000, '0000-00-00 00:00:00', 700000, 34, 'Thuê xe tập lái ', '2024-11-12', 'Bình thường ', 34, 1, '2024-11-08 08:22:24', 'ffff', 1, '2024-11-08 08:22:46', 'fffff', 'Đã trả', 1, '2024-11-05 09:47:55', ''),
(41, '2024-11-13', NULL, 'Phan Trường An ', '8404503237  ', 'P6, tp Trà Vinh ', '0977553274', 3, 5, '2024-11-13 07:00:37', '2024-11-13 09:00:37', 1400000, '2024-11-13 10:00:42', 700000, 33, 'Thuê xe tập láy ', '2024-11-13', 'Bình thường ', 33, 1, '2024-11-06 08:19:14', 'Yêu cầu duyệt ', 1, '2024-11-06 08:19:29', 'Duyệt thành công ', 'Đã trả', 1, '2024-11-06 08:18:39', ''),
(42, '2024-11-13', 85, '', '', '', '', 2, 4, '2024-11-13 08:00:05', '2024-11-13 10:00:06', 600000, '2024-11-13 11:00:38', 300000, 33, 'Thuê xe tập láy ', '2024-11-13', 'Bình thường ', 42, 1, '2024-11-06 09:35:59', 'Gửi phiếu ', 1, '2024-11-06 09:36:08', 'Duyệt ', 'Đã trả', 1, '2024-11-06 08:21:43', ''),
(43, '2024-11-13', NULL, 'Phạm Huyền Trân ', '8404503231', 'Hòa Hảo, Châu Thành, Trà Vinh ', '0977553272', 3, 5, '2024-11-06 05:00:46', '2024-11-06 09:00:46', 2800000, '2024-11-06 11:00:01', 1400000, 35, 'Thuê xe vận tải ', '2024-11-06', 'Bình thường ', 35, 1, '2024-11-06 16:12:37', 'Duyệt đi', 1, '2024-11-06 16:12:43', '', 'Đã trả', 1, '2024-11-06 16:12:04', ''),
(44, '2024-11-14', NULL, 'Nguyễn Thị Cẩm Nhung ', '8437501231', 'P9, tp Trà Vinh ', '0922733514', 3, 5, '2024-11-14 08:00:24', '2024-11-14 10:00:24', 1400000, '2024-11-14 11:00:03', 700000, 34, 'Thuê xe tập láy ', '2024-11-14', 'Xe bình thường', 45, 1, '2024-11-07 08:32:52', 'Gửi phiếu ', 1, '2024-11-07 08:33:04', 'OK duyệt ', 'Đã trả', 1, '2024-11-07 08:32:38', ''),
(45, '2024-11-13', NULL, 'Phạm Thị Ngọc Quỳnh ', '8437501238', 'Hòa Hảo, Châu Thành, Trà Vinh  ', '0977553272', 3, 5, '2024-11-12 09:00:47', '2024-11-12 11:00:47', 1400000, '2024-11-12 11:00:45', 0, 43, 'Thuê xe tập lái ', '2024-11-12', 'Bình thường ', 35, 1, '2024-11-07 14:26:57', 'Gửi phiếu ', 1, '2024-11-07 14:27:09', 'Ok duyệt ', 'Đã trả', 1, '2024-11-07 14:26:42', ''),
(46, '2024-11-20', 86, '', '', '', '', 1, 1, '2024-11-20 05:00:44', '2024-11-20 09:00:44', 2000000, '2024-11-20 08:00:43', 0, 34, 'Thuê xe tập láy ', '2024-11-22', 'Bình thường ', 34, 1, '2024-11-08 15:09:12', 'Gửi phiếu ', 1, '2024-11-08 15:09:25', 'Duyệt ', 'Đã trả', 1, '2024-11-08 15:08:36', ''),
(47, '2024-11-13', 88, '', '', '', '', 3, 5, '2024-11-05 05:00:51', '2024-11-05 07:00:51', 1400000, '2024-11-05 07:00:00', 0, 35, 'Thuê xe tập láy ', '2024-11-05', 'Bình thường ', 33, 1, '2024-11-11 10:21:59', 'Yêu cầu duyệt ', 1, '2024-11-11 10:22:07', 'Ok ', 'Đã trả', 1, '2024-11-11 10:21:45', ''),
(48, '2024-11-12', NULL, 'Trần Thị Thùy Linh ', '8404503239', 'P7, tp Trà Vinh ', '0922771552', 1, 2, '2024-11-12 05:00:52', '2024-11-12 17:00:21', 1000000, '0000-00-00 00:00:00', 0, 33, 'Thuê xe tập láy ', '2024-11-13', 'Bình thường ', 34, 1, '2024-11-11 10:48:56', 'Gửi phiếu yêu cầu duyệt ', 1, '2024-11-11 10:49:08', 'Duyệt OK ', 'Đã trả', 1, '2024-11-11 10:48:38', ''),
(49, '2024-11-14', NULL, 'Dương Phước Lộc', '8404503239', 'Hòa Hảo, Châu Thành, Trà Vinh   ', '0922733514 ', 1, 3, '2024-11-14 06:00:35', '2024-11-14 11:00:35', 700000, '0000-00-00 00:00:00', 0, 34, 'Thuê xe tập lái ', '2024-11-14', 'Bình thường ', 34, 1, '2024-11-23 09:03:14', 'Duyệt ', 1, '2024-11-23 09:03:27', 'Ok ', 'Đã trả', 1, '2024-11-23 09:02:50', ''),
(50, '2024-11-14', NULL, 'Trần Lưu Quang ', '8407501232  ', 'Hòa Hảo, Châu Thành, Trà Vinh    ', '0922771552 ', 1, 3, '2024-11-14 07:00:47', '2024-11-14 11:00:47', 700000, '0000-00-00 00:00:00', 500000, 35, 'Thuê xe tập láy ', '2024-11-14', 'Bình thường ', 34, 1, '2024-11-23 10:27:28', 'Duyệt nhanh ', 1, '2024-11-23 10:27:38', 'OK', 'Đã trả', 1, '2024-11-23 10:08:56', 'Sáng'),
(51, '2024-11-15', NULL, 'Nguyễn Ngọc Băng Nhi ', '8404503237  ', 'P7, tp Trà Vinh  ', '0922733514 ', 1, 3, '2024-11-14 07:00:05', '2024-11-14 11:00:05', 700000, '0000-00-00 00:00:00', 0, 35, 'Thuê xe tập lái ', '2024-11-14', 'Ok ', 34, 1, '2024-11-25 08:42:14', 'Gửi ', 1, '2024-11-25 08:42:23', 'OK', 'Đã trả', 1, '2024-11-25 08:34:02', 'Sáng'),
(52, '2024-11-16', NULL, 'Nguyễn Khắc Quốc ', '8404503239 ', 'Hòa Hảo, Châu Thành, Trà Vinh    ', '0977553274 ', 1, 3, '2024-11-15 13:00:17', '2024-11-15 17:00:17', 700000, '0000-00-00 00:00:00', 0, 36, 'Thuê xe tập lái ', '2024-11-15', 'Bình thường ', 34, 1, '2024-11-25 08:39:02', 'Yêu cầu duyệt ', 1, '2024-11-25 08:39:12', 'Duyệt ', 'Đã trả', 1, '2024-11-25 08:37:15', 'Trưa'),
(53, '2024-11-16', NULL, 'Trần Hữu Lượng ', '8404503239 ', 'Hòa Hảo, Châu Thành, Trà Vinh   ', '0977553271  ', 1, 3, '2024-11-14 18:00:00', '2024-11-14 22:00:00', 700000, '0000-00-00 00:00:00', 500000, 33, 'Thuê xe tập láy ', '2024-11-16', 'Bình thường ', 35, 1, '2024-11-25 09:34:01', 'Yêu cầu duyệt ', 1, '2024-11-25 09:34:25', 'Ok ', 'Đã trả', 1, '2024-11-25 09:32:08', 'Chiều'),
(54, '2025-01-04', NULL, 'Tô Lâm ', '8404503239', 'P7, tp Trà Vinh  ', '0977553275', 1, 1, '2025-01-04 07:00:00', '2025-01-04 09:00:00', 1000000, NULL, NULL, 35, 'Thuê xe du lịch  ', NULL, NULL, NULL, 1, '2025-01-04 09:02:58', 'Yêu cầu duyệt ', 1, '2025-01-04 09:03:22', 'Duyệt ', 'Đã duyệt', 1, '2025-01-04 09:02:02', 'Sáng'),
(55, '2025-01-04', NULL, 'Phạm Minh Chính ', '8437501232', 'Hà Nội ', '0922733514 ', 3, 5, '2025-01-04 09:00:00', '2025-01-04 11:00:00', 1400000, NULL, NULL, 35, 'Thuê xe chở hàng ', NULL, NULL, NULL, 1, '2025-01-04 09:42:55', 'Yêu cầu gửi ', 1, '2025-01-04 09:43:07', 'Duyệt ', 'Đã duyệt', 1, '2025-01-04 09:42:45', ''),
(56, '2025-01-14', NULL, 'Lê Văn Nở ', '8404503237  ', 'P6, tp Trà Vinh ', '0922771552 ', 4, 1, '2025-01-07 10:00:00', '2025-01-07 11:00:00', 500000, NULL, NULL, 36, 'Tập lái ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Đã nhập', 1, '2025-01-04 10:37:08', '');

-- --------------------------------------------------------

--
-- Table structure for table `ptx_xe`
--

DROP TABLE IF EXISTS `ptx_xe`;
CREATE TABLE IF NOT EXISTS `ptx_xe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_loai_xe` int(11) NOT NULL,
  `hieu_xe` varchar(50) DEFAULT NULL,
  `bien_so_xe` varchar(50) DEFAULT NULL,
  `tinh_trang_xe` text,
  `trang_thai` varchar(25) DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_loai_xe_xe` (`id_loai_xe`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ptx_xe`
--

INSERT INTO `ptx_xe` (`id`, `id_loai_xe`, `hieu_xe`, `bien_so_xe`, `tinh_trang_xe`, `trang_thai`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(1, 1, 'yurri ', '84AE-00752 ', 'Hoạt động bình thường ', 'Không khả dụng', NULL, NULL),
(2, 3, 'TaricT', '84F1-999.99', 'Hoạt động bình thường ', 'Khả dụng', NULL, NULL),
(3, 2, 'Tatachi', '84AE-00753', 'Bình thường ', 'Không khả dụng', NULL, NULL),
(4, 1, 'Yaki', '84AE-00754', 'Bình thường ', 'Khả dụng', 1, '2025-01-04 09:49:44');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `confirmation_token` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(6) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) DEFAULT NULL,
  `bind_to_ip` varchar(255) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `email_confirmed` smallint(1) NOT NULL DEFAULT '0',
  `fullname` varchar(55) DEFAULT NULL,
  `ho_ten` varchar(255) DEFAULT NULL COMMENT 'Họ tên của nhân viên',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`, `fullname`, `ho_ten`) VALUES
(1, 'khanhquy', 'k27A9nnlGrYP199v4taFyhYyiYzdSMqk', '$2y$13$d9pA.2iW7GoNtBiwYwGnp.S2bDXf.UGysqvFOninjwV/F7bNA6WJq', NULL, 1, 1, 1724233958, 1724233958, NULL, NULL, NULL, 0, 'Lâm Khánh Quy', NULL),
(2, 'Doremon', 'CbUlfXkgGty9wVyw8pBkQAMKcDNoDjbT', '$2y$13$1CeeFUEEWOOb/EYDx48wyud.XsRpz5zeIYbugSdt0/Kw9LzKFdQPu', NULL, 1, 0, 1724898409, 1724898409, '::1', '', 'lamq9797@gmil.com', 0, 'Trịnh Văn Xuân', NULL),
(3, 'ngocnhu', 'CXBtMabTG_6yYZ2AL_KBqUmY57aSkKUn', '$2y$13$8Xqx0wVSpeBAD.2xao0cae5EIz4pJeAWNhZlud6DwhkfzxzRzN9W2', NULL, 1, 0, 1729842182, 1729930761, '::1', '', '', 0, NULL, NULL),
(4, 'superadmin', '0ShdYDVzmZYLtQnRNKKIh8_VZ4LNBUHc', '$2y$13$ehzgTGhTnRlvw5RBlz1m6uW/wjq3j5eD/Qil88ruT/VVb2PKb3pZe', NULL, 1, 1, 1725413293, 1725413293, NULL, NULL, NULL, 0, NULL, NULL),
(5, 'quetran', 'GWS8hkCejSikYGoBqZ27ou509VsuC6L9', '$2y$13$4VCF27EkDfGbjuIfzQ0Mk.OZ.ka75EVPkzCFB1pFEgGCLrxMGxYyi', NULL, 1, 0, 1743287734, 1743311387, '127.0.0.1', '', '', 0, NULL, 'Quế Trân'),
(6, 'thaitran', 'LTH-GDcFt7UmEcf7xVKcq0cGyFJ2EsMo', '$2y$13$hFMAdiF3/DEPwT1jT.vgdOr3i0o27l4sSNvk8/yHOnnLcy29mrZAS', NULL, 1, 0, 1743287817, 1743287817, '127.0.0.1', '', '', 0, NULL, NULL),
(7, 'admin', 'ATvQY-dDXcPHYUuqutHMaf9YQ0fvQIuC', '$2y$13$aHWU1wUDIPj6idEAoAuU5.PyPMoZgl52yuFDYEhsNTJlMuXQdOYwO', NULL, 1, 1, 1743287842, 1743402885, '127.0.0.1', '', '', 0, NULL, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `language` char(2) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) DEFAULT NULL,
  `os` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=366 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '66c60a23e54e1', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724254755, 'Chrome', 'Windows'),
(2, '66c68dd09a82d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724288464, 'Chrome', 'Windows'),
(3, '66c6a3939045b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724294035, 'Chrome', 'Windows'),
(4, '66c6e417893cc', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724310551, 'Chrome', 'Windows'),
(5, '66c7e282138da', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724375682, 'Chrome', 'Windows'),
(6, '66c835157d7db', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724396821, 'Chrome', 'Windows'),
(7, '66c987bfcbae8', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724483519, 'Chrome', 'Windows'),
(8, '66cbd40f76f4f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724634127, 'Chrome', 'Windows'),
(9, '66cc2a249ea27', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724656164, 'Chrome', 'Windows'),
(10, '66cd27516cb6e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724720977, 'Chrome', 'Windows'),
(11, '66cd7852d689c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724741714, 'Chrome', 'Windows'),
(12, '66ce7960d35ae', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724807520, 'Chrome', 'Windows'),
(13, '66ce796266613', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724807522, 'Chrome', 'Windows'),
(14, '66cecd2786523', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1724828967, 'Chrome', 'Windows'),
(15, '66cfca007657e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1724893696, 'Chrome', 'Windows'),
(16, '66cfdc8657673', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 2, 1724898438, 'Chrome', 'Windows'),
(17, '66cfe5f66bfb8', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1724900854, 'Chrome', 'Windows'),
(18, '66d01f183406f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1724915480, 'Chrome', 'Windows'),
(19, '66d11d9284cff', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1724980626, 'Chrome', 'Windows'),
(20, '66d1700a4b901', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725001738, 'Chrome', 'Windows'),
(21, '66d26f435d7c9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725067075, 'Chrome', 'Windows'),
(22, '66d2c3571a351', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725088599, 'Chrome', 'Windows'),
(23, '66d48e504979a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725206096, 'Chrome', 'Windows'),
(24, '66d666cc7ec45', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725327052, 'Chrome', 'Windows'),
(25, '66d6b3c73d507', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725346759, 'Chrome', 'Windows'),
(26, '66d7b3bc578d2', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725412284, 'Chrome', 'Windows'),
(27, '66d7b424a80f7', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725412388, 'Chrome', 'Windows'),
(28, '66d808a69f13a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725434022, 'Chrome', 'Windows'),
(29, '66d90558382f9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725498712, 'Chrome', 'Windows'),
(30, '66d95986ba9e1', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725520262, 'Chrome', 'Windows'),
(31, '66da567a42f58', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725585018, 'Chrome', 'Windows'),
(32, '66daaa02a9cf0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725606402, 'Chrome', 'Windows'),
(33, '66dba995b33d5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725671829, 'Chrome', 'Windows'),
(34, '66dbff935b101', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725693843, 'Chrome', 'Windows'),
(35, '66de4ccc35005', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725844684, 'Chrome', 'Windows'),
(36, '66dea0e9c094b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725866217, 'Chrome', 'Windows'),
(37, '66df9e26babb8', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725931046, 'Chrome', 'Windows'),
(38, '66dff174cb518', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1725952372, 'Chrome', 'Windows'),
(39, '66e0f17b14f2d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726017915, 'Chrome', 'Windows'),
(40, '66e145006154a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726039296, 'Chrome', 'Windows'),
(41, '66e23fe86134d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726103528, 'Chrome', 'Windows'),
(42, '66e297b7833c2', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726126007, 'Chrome', 'Windows'),
(43, '66e39c4a8a9b5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726192714, 'Chrome', 'Windows'),
(44, '66e3e69e1907c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726211742, 'Chrome', 'Windows'),
(45, '66e4e77d33435', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726277501, 'Chrome', 'Windows'),
(46, '66e538ef3af50', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726298351, 'Chrome', 'Windows'),
(47, '66e787b38c806', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726449587, 'Chrome', 'Windows'),
(48, '66e7daa7aa3c2', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726470823, 'Chrome', 'Windows'),
(49, '66e8da3846839', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726536248, 'Chrome', 'Windows'),
(50, '66e92ce82a195', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726557416, 'Chrome', 'Windows'),
(51, '66ea2a0723545', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726622215, 'Chrome', 'Windows'),
(52, '66ea7e4831fb9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726643784, 'Chrome', 'Windows'),
(53, '66eaf150aacc0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726673232, 'Chrome', 'Windows'),
(54, '66eb7e7d49c0a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726709373, 'Chrome', 'Windows'),
(55, '66ebc40547546', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726727173, 'Chrome', 'Windows'),
(56, '66ebcf6fd4ca9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726730095, 'Chrome', 'Windows'),
(57, '66ecd3276fa43', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1726796583, 'Chrome', 'Windows'),
(58, '66ed2107cd34b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1726816519, 'Chrome', 'Windows'),
(59, '66ee1f0242cff', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1726881538, 'Chrome', 'Windows'),
(60, '66ee70d17b9d8', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1726902481, 'Chrome', 'Windows'),
(61, '66f0c1ab5cf8c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727054251, 'Chrome', 'Windows'),
(62, '66f114984874a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727075480, 'Chrome', 'Windows'),
(63, '66f13714db654', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727084308, 'Chrome', 'Windows'),
(64, '66f2139cedbd0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727140765, 'Chrome', 'Windows'),
(65, '66f26534edb12', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727161653, 'Chrome', 'Windows'),
(66, '66f3642556851', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727226917, 'Chrome', 'Windows'),
(67, '66f36dd3d23a1', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727229395, 'Chrome', 'Windows'),
(68, '66f370992da2e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727230105, 'Chrome', 'Windows'),
(69, '66f376132fda8', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727231507, 'Chrome', 'Windows'),
(70, '66f380d0ad74e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727234256, 'Chrome', 'Windows'),
(71, '66f386805a4fd', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727235712, 'Chrome', 'Windows'),
(72, '66f3b6bdef8b5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727248062, 'Chrome', 'Windows'),
(73, '66f3d17d19306', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 2, 1727254909, 'Chrome', 'Windows'),
(74, '66f3d1d3ebbc0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727254995, 'Chrome', 'Windows'),
(75, '66f4c05d8b6e6', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727316061, 'Chrome', 'Windows'),
(76, '66f50924cf507', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727334692, 'Chrome', 'Windows'),
(77, '66f6072c9d25e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727399724, 'Chrome', 'Windows'),
(78, '66f65a520f0a0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727421010, 'Chrome', 'Windows'),
(79, '66f757c3edb8d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727485892, 'Chrome', 'Windows'),
(80, '66f7abff116a0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727507455, 'Chrome', 'Windows'),
(81, '66f95ce5d937b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727618277, 'Chrome', 'Windows'),
(82, '66f9f8ac75bda', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727658156, 'Chrome', 'Windows'),
(83, '66fa50a2ae58a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727680674, 'Chrome', 'Windows'),
(84, '66fb4d007f37b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727745280, 'Chrome', 'Windows'),
(85, '66fba05b41d48', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727766619, 'Chrome', 'Windows'),
(86, '66fbb1d8660d3', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727771096, 'Chrome', 'Windows'),
(87, '66fc19990c00b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727797657, 'Chrome', 'Windows'),
(88, '66fca024438d9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727832100, 'Chrome', 'Windows'),
(89, '66fcf22bc88e5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727853099, 'Chrome', 'Windows'),
(90, '66fd051d2c66d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727857949, 'Chrome', 'Windows'),
(91, '66fd0b1097670', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727859472, 'Chrome', 'Windows'),
(92, '66fd123e45f2e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727861310, 'Chrome', 'Windows'),
(93, '66fdf16762217', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727918439, 'Chrome', 'Windows'),
(94, '66fe4aae4a00b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1727941294, 'Chrome', 'Windows'),
(95, '66ff41c3c35f0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728004547, 'Chrome', 'Windows'),
(96, '66ffb5035949d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728034051, 'Chrome', 'Windows'),
(97, '66ffb64b2b65d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728034379, 'Chrome', 'Windows'),
(98, '66ffb6810ad84', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728034433, 'Chrome', 'Windows'),
(99, '6700a3c55d799', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728095173, 'Chrome', 'Windows'),
(100, '6700a3dd48d98', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728095197, 'Chrome', 'Windows'),
(101, '6700e83753d5e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728112695, 'Chrome', 'Windows'),
(102, '6703366f801f0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728263791, 'Chrome', 'Windows'),
(103, '67038a8db8adf', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728285325, 'Chrome', 'Windows'),
(104, '6704876eca5a3', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728350062, 'Chrome', 'Windows'),
(105, '6704db5f4f623', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728371551, 'Chrome', 'Windows'),
(106, '670727216ceb3', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728522017, 'Chrome', 'Windows'),
(107, '67077d282e708', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728544040, 'Chrome', 'Windows'),
(108, '6708b5209cec9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728623904, 'Chrome', 'Windows'),
(109, '6708cb1840b9f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728629528, 'Chrome', 'Windows'),
(110, '6709c9d77afd9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728694743, 'Chrome', 'Windows'),
(111, '670c6e862bc79', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728867974, 'Chrome', 'Windows'),
(112, '670dbf79c1b0d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728954233, 'Chrome', 'Windows'),
(113, '670dc1d604a18', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728954838, 'Chrome', 'Windows'),
(114, '670dc29331a90', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728955027, 'Chrome', 'Windows'),
(115, '670dd623c239f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728960035, 'Chrome', 'Windows'),
(116, '670dde499661d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728962121, 'Chrome', 'Windows'),
(117, '670e1240c5d04', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1728975424, 'Chrome', 'Windows'),
(118, '670f10e96713e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729040617, 'Chrome', 'Windows'),
(119, '670f18eda99cf', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729042669, 'Chrome', 'Windows'),
(120, '670f65b736b0c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729062327, 'Chrome', 'Windows'),
(121, '671064b370e54', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729127603, 'Chrome', 'Windows'),
(122, '6710b5b185407', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729148337, 'Chrome', 'Windows'),
(123, '6711b57d97388', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729213821, 'Chrome', 'Windows'),
(124, '6711ba3faf65b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729215039, 'Chrome', 'Windows'),
(125, '671208d7c5e0a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729235159, 'Chrome', 'Windows'),
(126, '6712265a8be27', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729242714, 'Chrome', 'Windows'),
(127, '6715aa3fdf8ae', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729473088, 'Chrome', 'Windows'),
(128, '6715c59a8420e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729480090, 'Chrome', 'Windows'),
(129, '6715c59bc1d7b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729480091, 'Chrome', 'Windows'),
(130, '6715fe51b6307', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729494609, 'Chrome', 'Windows'),
(131, '6716fd9d67d46', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729559965, 'Chrome', 'Windows'),
(132, '6717503a05231', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729581114, 'Chrome', 'Windows'),
(133, '67184e1362064', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729646099, 'Chrome', 'Windows'),
(134, '6718a0f94172a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729667321, 'Chrome', 'Windows'),
(135, '6718a0fa82538', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729667322, 'Chrome', 'Windows'),
(136, '6718c48ea27ce', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1729676430, 'Chrome', 'Windows'),
(137, '67199e4931fb2', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1729732169, 'Chrome', 'Windows'),
(138, '6719f18f70de1', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1729753487, 'Chrome', 'Windows'),
(139, '671aeee2e7bc9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1729818339, 'Chrome', 'Windows'),
(140, '671b426655db5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1729839718, 'Chrome', 'Windows'),
(141, '671c426c73138', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1729905260, 'Chrome', 'Windows'),
(142, '671c95f978b16', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1729926649, 'Chrome', 'Windows'),
(143, '671ee4256bd4f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730077733, 'Chrome', 'Windows'),
(144, '671f3697c707c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730098839, 'Chrome', 'Windows'),
(145, '6720364af0838', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730164299, 'Chrome', 'Windows'),
(146, '6720874ee7268', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730185038, 'Chrome', 'Windows'),
(147, '6721864c32982', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730250316, 'Chrome', 'Windows'),
(148, '6721d8fba341f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730271483, 'Chrome', 'Windows'),
(149, '6722d7875b80b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730336647, 'Chrome', 'Windows'),
(150, '67232b21b9a17', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730358049, 'Chrome', 'Windows'),
(151, '67234d7ea3c7a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1730366846, 'Chrome', 'Windows'),
(152, '672429ccca3a7', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730423244, 'Chrome', 'Windows'),
(153, '672429f9531fb', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730423289, 'Chrome', 'Windows'),
(154, '67247deeb1c50', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730444782, 'Chrome', 'Windows'),
(155, '67257b88be52a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 3, 1730509704, 'Chrome', 'Windows'),
(156, '67258f1dd9162', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730514717, 'Chrome', 'Windows'),
(157, '6725d0b7ddfda', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730531511, 'Chrome', 'Windows'),
(158, '6725ee37f276c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 1, 1730539064, 'Chrome', 'Windows'),
(159, '67281d2547b0c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730682149, 'Chrome', 'Windows'),
(160, '6728718639050', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730703750, 'Chrome', 'Windows'),
(161, '67296efedce44', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730768638, 'Chrome', 'Windows'),
(162, '6729c3769ab39', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730790262, 'Chrome', 'Windows'),
(163, '672ac289416d3', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730855561, 'Chrome', 'Windows'),
(164, '672b14ec69238', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730876652, 'Chrome', 'Windows'),
(165, '672c13849d944', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730941828, 'Chrome', 'Windows'),
(166, '672c6622bc03e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1730962978, 'Chrome', 'Windows'),
(167, '672d649bcda04', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731028123, 'Chrome', 'Windows'),
(168, '672db7d84794d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731049432, 'Chrome', 'Windows'),
(169, '672eb7893e236', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731114889, 'Chrome', 'Windows'),
(170, '672f09631a955', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731135843, 'Chrome', 'Windows'),
(171, '6731585ec3f18', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731287134, 'Chrome', 'Windows'),
(172, '6731b047949ab', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731309639, 'Chrome', 'Windows'),
(173, '6731ca6a06883', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731316330, 'Chrome', 'Windows'),
(174, '6732ad3c3b6c4', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731374396, 'Chrome', 'Windows'),
(175, '6732fe77ac9b5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731395191, 'Chrome', 'Windows'),
(176, '6733175c0607b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731401564, 'Chrome', 'Windows'),
(177, '6733fbc2a31fd', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731460034, 'Chrome', 'Windows'),
(178, '67344f5e805e7', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731481438, 'Chrome', 'Windows'),
(179, '6735501a846b1', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731547162, 'Chrome', 'Windows'),
(180, '6735a367b3cde', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731568487, 'Chrome', 'Windows'),
(181, '6736f38f36158', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731654543, 'Chrome', 'Windows'),
(182, '673700bd9cb1f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731657917, 'Chrome', 'Windows'),
(183, '673703e2104bb', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731658722, 'Chrome', 'Windows'),
(184, '6737f20ef28ec', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731719695, 'Chrome', 'Windows'),
(185, '673844952a41b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731740821, 'Chrome', 'Windows'),
(186, '6738452783360', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731740967, 'Chrome', 'Windows'),
(187, '673a94250a350', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731892261, 'Chrome', 'Windows'),
(188, '673ab97e50f85', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731901822, 'Chrome', 'Windows'),
(189, '673abce173df4', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731902689, 'Chrome', 'Windows'),
(190, '673ae81d495d8', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731913757, 'Chrome', 'Windows'),
(191, '673be54fad634', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1731978575, 'Chrome', 'Windows'),
(192, '673c434db69a9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732002637, 'Chrome', 'Windows'),
(193, '673d373bf30a5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732065084, 'Chrome', 'Windows'),
(194, '673d8902f1afc', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732086019, 'Chrome', 'Windows'),
(195, '673e8952e1215', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732151634, 'Chrome', 'Windows'),
(196, '673edda28c845', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732173218, 'Chrome', 'Windows'),
(197, '673fdab76dd53', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732238007, 'Chrome', 'Windows'),
(198, '67402e8ec1945', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732259470, 'Chrome', 'Windows'),
(199, '67412dca1939b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732324810, 'Chrome', 'Windows'),
(200, '67417f7a7d21a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732345722, 'Chrome', 'Windows'),
(201, '6743449cf17b7', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732461725, 'Chrome', 'Windows'),
(202, '6743d0519bcd2', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732497489, 'Chrome', 'Windows'),
(203, '6743f6f56bda2', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732507381, 'Chrome', 'Windows'),
(204, '674420ed94033', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732518125, 'Chrome', 'Windows'),
(205, '6745220586c19', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732583941, 'Chrome', 'Windows'),
(206, '674575889de06', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732605320, 'Chrome', 'Windows'),
(207, '674670e17133a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732669665, 'Chrome', 'Windows'),
(208, '6746c5461bca2', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732691270, 'Chrome', 'Windows'),
(209, '6747c3601482f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732756320, 'Chrome', 'Windows'),
(210, '674814f1c688b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732777201, 'Chrome', 'Windows'),
(211, '674914202685e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732842528, 'Chrome', 'Windows'),
(212, '674966a56240e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732863653, 'Chrome', 'Windows'),
(213, '674a66f48df64', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732929268, 'Chrome', 'Windows'),
(214, '674ab807488ae', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1732950023, 'Chrome', 'Windows'),
(215, '674d093be9655', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733101884, 'Chrome', 'Windows'),
(216, '674d5aa4585fc', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733122724, 'Chrome', 'Windows'),
(217, '674e5cf84a82d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733188856, 'Chrome', 'Windows'),
(218, '674eacada9c22', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733209261, 'Chrome', 'Windows'),
(219, '674fad27b50eb', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733274919, 'Chrome', 'Windows'),
(220, '674fff978cffd', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733296023, 'Chrome', 'Windows'),
(221, '6751006cec3b7', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733361773, 'Chrome', 'Windows'),
(222, '67515195ae47d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733382549, 'Chrome', 'Windows'),
(223, '6753a0c9bc4d6', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733533897, 'Chrome', 'Windows'),
(224, '6753f55390979', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733555539, 'Chrome', 'Windows'),
(225, '67564836e0f8a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733707830, 'Chrome', 'Windows'),
(226, '675692c01f173', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733726912, 'Chrome', 'Windows'),
(227, '675692c184e07', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733726913, 'Chrome', 'Windows'),
(228, '675795ab10add', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733793195, 'Chrome', 'Windows'),
(229, '6757e6f7bae53', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733814007, 'Chrome', 'Windows'),
(230, '6758e948bccaa', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733880136, 'Chrome', 'Windows'),
(231, '67593bb07020b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733901232, 'Chrome', 'Windows'),
(232, '675a3a0b8942d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733966347, 'Chrome', 'Windows'),
(233, '675a8c5f26215', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1733987423, 'Chrome', 'Windows'),
(234, '675b8925ebe67', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734052134, 'Chrome', 'Windows'),
(235, '675bdef2f19f0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734074099, 'Chrome', 'Windows'),
(236, '675cdbc82e51c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734138824, 'Chrome', 'Windows'),
(237, '675d2eb697835', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734160054, 'Chrome', 'Windows'),
(238, '675f7e7e7a1b7', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734311550, 'Chrome', 'Windows'),
(239, '675fce12b7ea7', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734331922, 'Chrome', 'Windows'),
(240, '6760cc1b47456', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734396955, 'Chrome', 'Windows'),
(241, '67611f558cad6', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734418261, 'Chrome', 'Windows'),
(242, '67611fcc57b7c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 1, 1734418380, 'Chrome', 'Windows'),
(243, '67621ecd8e895', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734483661, 'Chrome', 'Windows'),
(244, '67627144ed10b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734504773, 'Chrome', 'Windows'),
(245, '6762ecfeb1a9f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734536446, 'Chrome', 'Windows'),
(246, '67636f10cff31', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734569744, 'Chrome', 'Windows'),
(247, '67636f1265c1c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734569746, 'Chrome', 'Windows'),
(248, '6763c0eb7d4bf', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734590699, 'Chrome', 'Windows'),
(249, '6764c2af89686', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734656687, 'Chrome', 'Windows'),
(250, '676612e87c580', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734742760, 'Chrome', 'Windows'),
(251, '676667d5243ae', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734764501, 'Chrome', 'Windows'),
(252, '6768b649d57dd', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734915657, 'Chrome', 'Windows'),
(253, '6768fe789f25d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734934136, 'Chrome', 'Windows'),
(254, '676907c4b491e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1734936516, 'Chrome', 'Windows'),
(255, '676a0883dbf10', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735002243, 'Chrome', 'Windows'),
(256, '676a5b939646e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735023507, 'Chrome', 'Windows'),
(257, '676a7398b8f2e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735029656, 'Chrome', 'Windows'),
(258, '676b5c651780e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735089253, 'Chrome', 'Windows'),
(259, '676bacdaaa97f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735109850, 'Chrome', 'Windows'),
(260, '676cb260a6aca', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735176800, 'Chrome', 'Windows'),
(261, '676d072f4d31b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735198511, 'Chrome', 'Windows'),
(262, '676dfd8562e3c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735261573, 'Chrome', 'Windows'),
(263, '676e54956ad18', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735283861, 'Chrome', 'Windows'),
(264, '676fa1635f6c0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735369059, 'Chrome', 'Windows'),
(265, '6771f1929f90a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735520658, 'Chrome', 'Windows'),
(266, '677244e59445c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735541989, 'Chrome', 'Windows'),
(267, '67734386ddbff', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735607174, 'Chrome', 'Windows'),
(268, '677395c9a0aa5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735628233, 'Chrome', 'Windows');
INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(269, '677495f823eae', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735693816, 'Chrome', 'Windows'),
(270, '6774e81b392ba', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735714843, 'Chrome', 'Windows'),
(271, '6775e6f043d03', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735780080, 'Chrome', 'Windows'),
(272, '6776392446937', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735801124, 'Chrome', 'Windows'),
(273, '6777383849c3e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735866424, 'Chrome', 'Windows'),
(274, '67778bcc94710', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735887820, 'Chrome', 'Windows'),
(275, '67788b27687c1', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735953191, 'Chrome', 'Windows'),
(276, '6778dd11125b1', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1735974161, 'Chrome', 'Windows'),
(277, '677b2dc631136', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736125894, 'Chrome', 'Windows'),
(278, '677b8197b3176', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736147351, 'Chrome', 'Windows'),
(279, '677b81990a01d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736147353, 'Chrome', 'Windows'),
(280, '677c7d00c578a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736211712, 'Chrome', 'Windows'),
(281, '677ccf0b8af69', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736232715, 'Chrome', 'Windows'),
(282, '677ce91122de9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736239377, 'Chrome', 'Windows'),
(283, '677dcf3b06d62', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736298299, 'Chrome', 'Windows'),
(284, '677e2819dcef7', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736321049, 'Chrome', 'Windows'),
(285, '677e281e3478d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736321054, 'Chrome', 'Windows'),
(286, '677e282175237', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736321057, 'Chrome', 'Windows'),
(287, '677e2823bd4ca', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736321059, 'Chrome', 'Windows'),
(288, '677e2825acbca', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736321061, 'Chrome', 'Windows'),
(289, '677e282710914', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736321063, 'Chrome', 'Windows'),
(290, '677e282894395', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736321064, 'Chrome', 'Windows'),
(291, '677e282a06a5a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736321066, 'Chrome', 'Windows'),
(292, '677f2092e60d6', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736384659, 'Chrome', 'Windows'),
(293, '677f727c29500', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736405628, 'Chrome', 'Windows'),
(294, '678071b971502', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736470969, 'Chrome', 'Windows'),
(295, '6780c54c18255', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736492364, 'Chrome', 'Windows'),
(296, '6781c52f5ef00', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736557871, 'Chrome', 'Windows'),
(297, '67821bc0f28e9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736580033, 'Chrome', 'Windows'),
(298, '678466b5ac867', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736730293, 'Chrome', 'Windows'),
(299, '6784bbda530d3', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736752090, 'Chrome', 'Windows'),
(300, '6785b6edcbb07', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736816365, 'Chrome', 'Windows'),
(301, '67860b5a457c6', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736837978, 'Chrome', 'Windows'),
(302, '6787095879f3f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 1, 1736903000, 'Chrome', 'Windows'),
(303, '67875ba3e5206', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1736924067, 'Chrome', 'Windows'),
(304, '67885b9fdd565', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1736989599, 'Chrome', 'Windows'),
(305, '6788aa28eb232', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737009705, 'Chrome', 'Windows'),
(306, '6789aa9e03e42', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737075358, 'Chrome', 'Windows'),
(307, '6789fe059e4fa', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737096709, 'Chrome', 'Windows'),
(308, '678b01734590c', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737163123, 'Chrome', 'Windows'),
(309, '678b5918b0585', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737185560, 'Chrome', 'Windows'),
(310, '678da78175b2a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737336705, 'Chrome', 'Windows'),
(311, '678df2dc643e8', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737355996, 'Chrome', 'Windows'),
(312, '678ef2c173eb8', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737421505, 'Chrome', 'Windows'),
(313, '678f462b06e7a', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737442859, 'Chrome', 'Windows'),
(314, '679043962039d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737507734, 'Chrome', 'Windows'),
(315, '679097a938068', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737529257, 'Chrome', 'Windows'),
(316, '6790b9d30b737', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737538003, 'Chrome', 'Windows'),
(317, '6790b9d6171fd', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737538006, 'Chrome', 'Windows'),
(318, '6790b9d8b8712', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737538008, 'Chrome', 'Windows'),
(319, '679195f827cad', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737594360, 'Chrome', 'Windows'),
(320, '6791e789c3a16', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737615241, 'Chrome', 'Windows'),
(321, '6792ec296e0f3', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737681961, 'Chrome', 'Windows'),
(322, '67933ddcb79f8', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737702876, 'Chrome', 'Windows'),
(323, '67943ce107108', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1737768161, 'Chrome', 'Windows'),
(324, '67a016c5c573d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738544837, 'Chrome', 'Windows'),
(325, '67a166c70b432', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738630855, 'Chrome', 'Windows'),
(326, '67a1bd7c7b2d0', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738653052, 'Chrome', 'Windows'),
(327, '67a2b898955af', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738717336, 'Chrome', 'Windows'),
(328, '67a30bcc166de', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738738636, 'Chrome', 'Windows'),
(329, '67a409350742d', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738803509, 'Chrome', 'Windows'),
(330, '67a45e3a2ece9', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738825274, 'Chrome', 'Windows'),
(331, '67a55b9e8ad88', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738890142, 'Chrome', 'Windows'),
(332, '67a57eafa166f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738899119, 'Chrome', 'Windows'),
(333, '67a5ad7d1cef6', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738911101, 'Chrome', 'Windows'),
(334, '67a6b4640fee4', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1738978404, 'Chrome', 'Windows'),
(335, '67a7094302889', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1739000131, 'Chrome', 'Windows'),
(336, '67a94e321d846', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1739148850, 'Chrome', 'Windows'),
(337, '67a9a4159ea20', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1739170837, 'Chrome', 'Windows'),
(338, '67aaa12d8d700', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1739235629, 'Chrome', 'Windows'),
(339, '67aaf65a943b5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1739257434, 'Chrome', 'Windows'),
(340, '67ac065e65c2b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1739327070, 'Chrome', 'Windows'),
(341, '67ac4783624ab', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1739343747, 'Chrome', 'Windows'),
(342, '67ad45d9993ce', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1739408857, 'Chrome', 'Windows'),
(343, '67ae97aa562d1', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 1, 1739495338, 'Chrome', 'Windows'),
(344, '67aee92d0c007', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36', 1, 1739516205, 'Chrome', 'Windows'),
(345, '67afec562a49b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36', 1, 1739582550, 'Chrome', 'Windows'),
(346, '67aff30e0ee01', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36', 1, 1739584270, 'Chrome', 'Windows'),
(347, '67c02360228e2', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36', 1, 1740645216, 'Chrome', 'Windows'),
(348, '67d2a4df7918f', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1741858015, 'Chrome', 'Windows'),
(349, '67d387070eaa5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1741915911, 'Chrome', 'Windows'),
(350, '67db7dc5208ef', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1742437829, 'Chrome', 'Windows'),
(351, '67e0b41d58fb5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1742779421, 'Chrome', 'Windows'),
(352, '67e268983abb1', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1742891160, 'Chrome', 'Windows'),
(353, '67e26d57ddf3b', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1742892375, 'Chrome', 'Windows'),
(354, '67e351b4935a5', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1742950836, 'Chrome', 'Windows'),
(355, '67e36642d0458', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1742956098, 'Chrome', 'Windows'),
(356, '67e3acc33a79e', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1742974147, 'Chrome', 'Windows'),
(357, '67e4a3031b2a4', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1743037187, 'Chrome', 'Windows'),
(358, '67e4f8b385c78', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1743059123, 'Chrome', 'Windows'),
(359, '67e513936cb57', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1743066003, 'Chrome', 'Windows'),
(360, '67e5f6cac9167', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1743124170, 'Chrome', 'Windows'),
(361, '67e6495139213', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1743145297, 'Chrome', 'Windows'),
(362, '67e66a45beeaf', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 4, 1743153733, 'Chrome', 'Windows'),
(363, '67e74a5514da6', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 4, 1743211093, 'Chrome', 'Windows'),
(364, '67e87588bc5da', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 4, 1743287688, 'Chrome', 'Windows'),
(365, '67ea372028f4c', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 7, 1743402784, 'Chrome', 'Windows');

-- --------------------------------------------------------

--
-- Table structure for table `vb_dm_loai_van_ban`
--

DROP TABLE IF EXISTS `vb_dm_loai_van_ban`;
CREATE TABLE IF NOT EXISTS `vb_dm_loai_van_ban` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_loai` varchar(255) NOT NULL,
  `ghi_chu` text,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vb_dm_loai_van_ban`
--

INSERT INTO `vb_dm_loai_van_ban` (`id`, `ten_loai`, `ghi_chu`, `nguoi_tao`, `thoi_gian_tao`) VALUES
(1, 'HD', NULL, 1, '2024-08-20 15:22:25'),
(21, 'Hợp đồng ', 'văn bản hợp đồng ', 1, '2024-09-30 09:58:47');

-- --------------------------------------------------------

--
-- Table structure for table `vb_van_ban`
--

DROP TABLE IF EXISTS `vb_van_ban`;
CREATE TABLE IF NOT EXISTS `vb_van_ban` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_loai_van_ban` int(11) NOT NULL,
  `so_vb` varchar(255) NOT NULL,
  `ngay_ky` date NOT NULL,
  `trich_yeu` varchar(255) NOT NULL,
  `nguoi_ky` varchar(255) NOT NULL,
  `vbden_ngay_den` date DEFAULT NULL,
  `so_vao_so` int(11) DEFAULT NULL,
  `vbden_nguoi_nhan` int(11) DEFAULT NULL,
  `vbden_ngay_chuyen` date DEFAULT NULL,
  `vbdi_noi_nhan` varchar(255) DEFAULT NULL,
  `vbdi_so_luong_ban` int(11) DEFAULT NULL,
  `vbdi_ngay_chuyen` date DEFAULT NULL,
  `ghi_chu` varchar(255) DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `so_loai_van_ban` varchar(255) DEFAULT NULL,
  `nam` year(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk-id_loai_van_ban_dm_loai_van_ban` (`id_loai_van_ban`),
  KEY `fk-vbden_nguoi_nhan_nhan_vien` (`vbden_nguoi_nhan`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vb_van_ban`
--

INSERT INTO `vb_van_ban` (`id`, `id_loai_van_ban`, `so_vb`, `ngay_ky`, `trich_yeu`, `nguoi_ky`, `vbden_ngay_den`, `so_vao_so`, `vbden_nguoi_nhan`, `vbden_ngay_chuyen`, `vbdi_noi_nhan`, `vbdi_so_luong_ban`, `vbdi_ngay_chuyen`, `ghi_chu`, `nguoi_tao`, `thoi_gian_tao`, `so_loai_van_ban`, `nam`) VALUES
(1, 1, '13/2024', '2024-08-02', 'cc', 'Nguyễn Văn Linh       ', '0000-00-00', 1, NULL, '0000-00-00', NULL, NULL, NULL, 'vv', 1, '2024-08-21 22:41:52', 'VB_DEN', 2024),
(2, 1, '127/2024', '2024-08-03', 'Về việc Hợp đồng ', 'Nguyễn Văn Linh       ', '0000-00-00', 2, NULL, '0000-00-00', NULL, NULL, NULL, 'ff', 1, '2024-08-22 10:17:07', 'VB_DEN', 2024),
(3, 1, '13/2024', '2024-08-09', 'tt', 'Nguyễn Văn Linh       ', '0000-00-00', 3, NULL, '0000-00-00', NULL, NULL, NULL, 'gg', 1, '2024-08-22 14:24:20', 'VB_DEN', 2024),
(19, 1, '16/2024', '2024-09-06', 'Hợp đồng', 'Lê Thành Nam ', NULL, NULL, NULL, NULL, 'Sở Tài nguyên và Môi trường  ', 5, '0000-00-00', 'Hợp đồng ', 1, '2024-09-18 09:20:14', 'VB_DI', 2024),
(24, 1, '14/2024', '2024-08-30', 'fffff', 'Lê Văn Lĩnh   ', NULL, NULL, NULL, NULL, 'Trường Đại học Trà Vinh ', 6, '2024-09-18', 'ffffff', 1, '2024-09-18 10:00:51', 'VB_DI', 2024),
(26, 21, '14/2024', '2024-10-17', 'Văn bản hợp ', 'Lê Thành Nam  ', NULL, NULL, NULL, NULL, 'Trường Đại học Trà Vinh  ', 4, '2024-10-18', 'Văn bản hợp đồng xây dựng khu A4 khung viên trường Đại học Trà Vinh ', 1, '2024-10-01 09:03:17', 'VB_DI', 2024),
(28, 21, '15/2024', '2024-10-31', 'Về việc hợp đồng xây dựng công trình công viên Trà Vinh ', 'Lê Văn Lĩnh ', NULL, NULL, NULL, NULL, 'UBND tỉnh Trà Vinh', 2, '2024-10-25', 'Hợp đồng ', 1, '2024-10-01 09:15:30', 'VB_DI', 2024),
(31, 21, '14', '1970-01-01', 'Văn bản hợp đồng ', 'Lê Văn Lĩnh ', NULL, 14, NULL, NULL, '<p>Sở lao động tỉnh Tr&agrave; Vinh</p>', 4, '1970-01-01', '<p>Văn bản hợp đồng&nbsp;</p>', 1, '2024-10-04 14:42:04', 'Văn bản đi', 2024),
(32, 21, '2', '2025-07-09', 'Hợp đồng ', 'Lê Văn Lĩnh    ', NULL, 12, NULL, NULL, '<p>Sở T&agrave;i Nguy&ecirc;n&nbsp;</p>', 3, '2024-12-11', '<p>Vb hợp đồng&nbsp;</p>', 1, '2024-11-15 15:56:01', 'VBDI', 2024);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hv_hoc_phi`
--
ALTER TABLE `hv_hoc_phi`
  ADD CONSTRAINT `fk-id_hang_hp_hang` FOREIGN KEY (`id_hang`) REFERENCES `hv_hang_dao_tao` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `hv_hoc_vien`
--
ALTER TABLE `hv_hoc_vien`
  ADD CONSTRAINT `fk-id_hang_hang_dao_tao` FOREIGN KEY (`id_hang`) REFERENCES `hv_hang_dao_tao` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk-id_khoa_hoc_khoa_hoc` FOREIGN KEY (`id_khoa_hoc`) REFERENCES `hv_khoa_hoc` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_nhom` FOREIGN KEY (`id_nhom`) REFERENCES `hv_nhom` (`id`);

--
-- Constraints for table `hv_khoa_hoc`
--
ALTER TABLE `hv_khoa_hoc`
  ADD CONSTRAINT `fk-id_hang_kh_hang` FOREIGN KEY (`id_hang`) REFERENCES `hv_hang_dao_tao` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `hv_nhom`
--
ALTER TABLE `hv_nhom`
  ADD CONSTRAINT `hv_khoa_hoc` FOREIGN KEY (`id_khoa_hoc`) REFERENCES `hv_khoa_hoc` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `hv_nop_hoc_phi`
--
ALTER TABLE `hv_nop_hoc_phi`
  ADD CONSTRAINT `fk-id_hoc_vien_hp_hoc_vien` FOREIGN KEY (`id_hoc_vien`) REFERENCES `hv_hoc_vien` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `hv_tai_lieu_khoa_hoc`
--
ALTER TABLE `hv_tai_lieu_khoa_hoc`
  ADD CONSTRAINT `fk-id_khoa_hoc_tl_khoa_hoc` FOREIGN KEY (`id_khoa_hoc`) REFERENCES `hv_khoa_hoc` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `kho_file`
--
ALTER TABLE `kho_file`
  ADD CONSTRAINT `fk-id_loai_ho_so_loai_ho_so` FOREIGN KEY (`loai_file`) REFERENCES `kho_loai_file` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `kho_hop`
--
ALTER TABLE `kho_hop`
  ADD CONSTRAINT `fk-id_ngan_ngan` FOREIGN KEY (`id_ngan`) REFERENCES `kho_ngan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `kho_ke`
--
ALTER TABLE `kho_ke`
  ADD CONSTRAINT `fk-id_kho_kho` FOREIGN KEY (`id_kho`) REFERENCES `kho_kho` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `kho_luu_kho`
--
ALTER TABLE `kho_luu_kho`
  ADD CONSTRAINT `fk-id_hop_luu_hop` FOREIGN KEY (`id_hop`) REFERENCES `kho_hop` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-id_ke_luu_ke` FOREIGN KEY (`id_ke`) REFERENCES `kho_ke` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-id_kho_luu_kho` FOREIGN KEY (`id_kho`) REFERENCES `kho_kho` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-id_ngan_luu_ngan` FOREIGN KEY (`id_ngan`) REFERENCES `kho_ngan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `kho_ngan`
--
ALTER TABLE `kho_ngan`
  ADD CONSTRAINT `fk-id_ke_ke` FOREIGN KEY (`id_ke`) REFERENCES `kho_ke` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lh_lich_hoc`
--
ALTER TABLE `lh_lich_hoc`
  ADD CONSTRAINT `lh_giao_vien` FOREIGN KEY (`id_giao_vien`) REFERENCES `nv_nhan_vien` (`id`),
  ADD CONSTRAINT `lh_khoa_hoc` FOREIGN KEY (`id_khoa_hoc`) REFERENCES `hv_khoa_hoc` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lh_nhom_hoc` FOREIGN KEY (`id_nhom`) REFERENCES `hv_nhom` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lh_phong_hoc` FOREIGN KEY (`id_phong`) REFERENCES `lh_phong_hoc` (`id`);

--
-- Constraints for table `lh_lich_thi`
--
ALTER TABLE `lh_lich_thi`
  ADD CONSTRAINT `fk_gvg` FOREIGN KEY (`id_giao_vien_gac`) REFERENCES `nv_nhan_vien` (`id`),
  ADD CONSTRAINT `fk_khoa_hoc_lich_thi` FOREIGN KEY (`id_khoa_hoc`) REFERENCES `hv_khoa_hoc` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_nhom_lich_thi` FOREIGN KEY (`id_nhom`) REFERENCES `hv_nhom` (`id`),
  ADD CONSTRAINT `lh_lich_thi_ibfk_1` FOREIGN KEY (`id_phong_thi`) REFERENCES `lh_phong_hoc` (`id`);

--
-- Constraints for table `lh_phan_thi`
--
ALTER TABLE `lh_phan_thi`
  ADD CONSTRAINT `fk_hang` FOREIGN KEY (`id_hang`) REFERENCES `hv_hang_dao_tao` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `nv_day`
--
ALTER TABLE `nv_day`
  ADD CONSTRAINT `fk-id_hang_xe_hang_xe` FOREIGN KEY (`id_hang_xe`) REFERENCES `hv_hang_dao_tao` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-id_nhan_vien_day_nhan_vien` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nv_nhan_vien` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `nv_nhan_vien`
--
ALTER TABLE `nv_nhan_vien`
  ADD CONSTRAINT `fk-id_phong_ban_nv` FOREIGN KEY (`id_phong_ban`) REFERENCES `nv_phong_ban` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-id_to_nv` FOREIGN KEY (`id_to`) REFERENCES `nv_to` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-tai_khoan_user` FOREIGN KEY (`tai_khoan`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `nv_to`
--
ALTER TABLE `nv_to`
  ADD CONSTRAINT `fk-id_phong_ban_to` FOREIGN KEY (`id_phong_ban`) REFERENCES `nv_phong_ban` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ptx_loai_hinh_thue`
--
ALTER TABLE `ptx_loai_hinh_thue`
  ADD CONSTRAINT `fk-loai_xe` FOREIGN KEY (`id_loai_xe`) REFERENCES `ptx_loai_xe` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ptx_phieu_thue_xe`
--
ALTER TABLE `ptx_phieu_thue_xe`
  ADD CONSTRAINT `fk-id_xe` FOREIGN KEY (`id_xe`) REFERENCES `ptx_xe` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-loai_hinh_thue` FOREIGN KEY (`id_loai_hinh_thue`) REFERENCES `ptx_loai_hinh_thue` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ptx_xe`
--
ALTER TABLE `ptx_xe`
  ADD CONSTRAINT `fk-id_loai_xe_xe` FOREIGN KEY (`id_loai_xe`) REFERENCES `ptx_loai_xe` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `vb_van_ban`
--
ALTER TABLE `vb_van_ban`
  ADD CONSTRAINT `fk-id_loai_van_ban_dm_loai_van_ban` FOREIGN KEY (`id_loai_van_ban`) REFERENCES `vb_dm_loai_van_ban` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-vbden_nguoi_nhan_nhan_vien` FOREIGN KEY (`vbden_nguoi_nhan`) REFERENCES `nv_nhan_vien` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
